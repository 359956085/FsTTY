#### v1.4.28

- Added `console.getcursorpos()` to get the cursor position.
- Updated `os.getscreeninfo()` to include the cursor position.
- Changed character width measurements in Windows Terminal to accommodate certain fully qualified color emoji variants such as "✔️" vs "✔".  The former is U+2714 U+FE0F and Windows Terminal draws a double-width color emoji; the latter is U+2714 and Windows Terminal draws a single-width character in the current font.  Note that Windows Terminal draws the characters; Clink just tries to make the best prediction it can about how Windows Terminal will draw the characters.
- Fixed display glitch where auto-suggest caused the display to scroll up an extra line at the bottom of the screen.
- Fixed display glitch where cursor position was wrong when the input line ends with a history expansion directive that ends exactly at the right edge of the terminal.
- Fixed `cmd.ctrld_exits` so <kbd>Ctrl</kbd>-<kbd>D</kbd> always exits with return code 0, so that terminal programs allow the shell window to close gracefully.
- Fixed mouse input when the `horizontal-scroll-mode` inputrc variable is `on`.
- Fixed missing prompt text when a prompt filter encounters an unhandled Lua error; now a placeholder prompt string is used so it's clear where the prompt is.
- Fixed [#467](https://github.com/chrisant996/clink/issues/467); On-Screen Keyboard in Swedish keyboard layout can't type `\`.
- Internal improvements.

#### v1.4.27

- Fixed when the `terminal.emulate` setting is `auto` on Windows 8.1 and earlier (regression introduced in v1.4.26).

#### v1.4.26

- Added built-in support for shell integration with Windows Terminal v1.18 and higher.  _Note: Windows Terminal gets confused about the command line text when the transient prompt is enabled._
- Changed `clink.getansihost()` to return two strings; the first string is the mode in use, and the new second string is what Clink detected (and will use when the `terminal.emulation` setting is `auto`).
- Fixed to use terminal emulation when the `terminal.emulate` setting is `auto` and ANSICON is present.  Clink's output is no longer able to be intercepted by ANSICON, so bypass it and use Clink's own terminal emulation.
- Fixed [#461](https://github.com/chrisant996/clink/issues/461); crash due to invalid RVA in ANSI32.DLL or ANSI64.DLL (ANSICON).

#### v1.4.25

- Now `os.issignaled()` works during `onendedit` and `onfilterinput` events.
- Improve emulation for <kbd>F7</kbd> history popup (the `win-history-popup` command); <kbd>Left</kbd> or <kbd>Right</kbd> replace the input text with the selected line.
- Transient prompt filters can suppress the transient prompt on a case by case basis by returning `nil, false`.
- Fixed typo in `clink set --help` text.
- Fixed where the prompt prefix (from v1.4.24) is inserted in the prompt string, so that shell integration escape codes can work properly.
- Fixed [#457](https://github.com/chrisant996/clink/issues/457); unrecognized OSC escape codes accidentally stripped from prompt string.

#### v1.4.24

- Added `path.fnmatch()` which behaves like the Linux `fnmatch(3)` function.
- Added `os.globmatch()` which performs recursive file pattern globbing [the same as git does](https://git-scm.com/docs/gitignore#_pattern_format).
- Added support for `%CLINK_PROMPT_PREFIX%`, `%CLINK_PROMPT_SUFFIX%`, `%CLINK_RPROMPT_PREFIX%`, and `%CLINK_RPROMPT_SUFFIX%` to provide prefix/suffix strings to surround the prompt strings, and for prompt filters to define a `:surround()` function to add their own prefix/suffix strings if needed.
- Fixed `~` by itself to change directories, the same as `~\`.
- Fixed horizontal scrolling in popup lists (is possible whenever the item doesn't fit and no items contain control codes).
- Fixed [#452](https://github.com/chrisant996/clink/issues/452); `history delete #` doesn't work (regression introduced in v1.1.43).
- Fixed [#448](https://github.com/chrisant996/clink/issues/448); completion malfunction with `..\does_not_exist` (regression introduced in v1.4.1).

#### v1.4.23

- Added help message in `clink-select-complete`: when descriptions are shown below the matches, this adds text to mention that <kbd>F1</kbd> toggles showing descriptions inline with the matches.
- Added `clink update --check` to only check for an update without installing it.

#### v1.4.22

- Fixed `clink-select-complete` to use per-match `appendchar` when present.
- Fixed repetitive unnecessary work in the background when the `completion` auto-suggest strategy encounters a `fromhistory` argument slot in an argmatcher.
- Fixed the installer `/S` flag (silent install) so it returns exit code 0 on success.

#### v1.4.21

- The `clink-diagnostics` command can report merged argmatchers.  When a numeric arg of 2 or greater is given (e.g. <kbd>Alt</kbd>-<kbd>2</kbd> <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd>) then it includes a list of defined argmatchers.  The list now also reports any merging of argmatchers that occurred.
- Fixed `clink update` so `winget` doesn't get confused about whether an update is available for Clink.  Once `winget update clink` performs an update, or once a Clink v1.4.21 or greater .exe installer is run, then `winget` should stop getting confused.

#### v1.4.20

- Fixed `os.isfile()` and `os.isdir()` when the specified name contains `<` or `>` or `"`, which are special wildcard characters for MS-DOS compatibility.  This caused an error when typing `"<`, which then mistakenly thought a completion script named `<.lua` existed.
- Fixed `rl.expandtilde()` to omit a trailing backslash when expanding `~` by itself.  This is to avoid running afoul of the [`\"` parsing rules](https://learn.microsoft.com/en-us/windows/win32/api/shellapi/nf-shellapi-commandlinetoargvw) for `argv[]` for programs.
- Fixed potential crash when the `clink` command line takes more bytes as UTF8 than it does as UTF16.

#### v1.4.19

- Added `builder:setforcequoting()` to force quoting rules to be applied to matches even if they aren't filenames.  This also reverts "quoting for non-filename completions" in v1.4.13; there isn't a safe and backward-compatible way to automatically deduce when non-filenames matches need quoting, so a match generator needs to turn it on explicitly when desired.

#### v1.4.18

- Added `clink.oninputlinechanged()` to register a function to be called whenever the input line is changed.

#### v1.4.17

- Added `os.isuseradmin()` to get whether CMD is running as an admin account.
- Added `os.getfileversion()` to get a table with version information if the file contains a Windows version info resource.
- The `clink-diagnostics` command now reports costs for Lua event callback functions when a numeric arg is given (e.g. <kbd>Alt</kbd>-<kbd>1</kbd> <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd>) or when the `lua.debug` setting is enabled.

#### v1.4.16

- Added `history.show_preview` setting that controls whether to show a preview of history expansions (previously it was inferred by whether `color.histexpand` was set).
- Added detection for problematic codes in the prompt string.  The `clink-diagnostics` <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd> command reports problem codes in the prompt string.  When certain problem codes exist in the prompt string, then Clink compensates by reprinting the entire input line after printing the prompt string.  Ideally, the prompt string should be fixed by the user, but sometimes that's difficult if the prompt string was generated by a tool.
- **Potential Breaking Change:** Fixed how hidden and system files are handled by `os.globdirs()` and `os.globfiles()` (it had never worked properly).  It worked fine with the default modes of the `files.hidden` and `files.system` settings and `match-hidden-files` config variable.  But if any of those were changed from the default values then malfunctions could occur.  With the fix, in backward compatibility mode the `files.hidden` and `files.system` settings and `match-hidden-files` config variable control whether `os.globdirs()` and `os.globfiles()` find hidden or system files, as before, and things can potentially malfunction.  When the optional `extrainfo` argument is non-zero or when a new optional `flags` table is passed to them, they now default to including hidden files and omitting system files, but the `flags` table can override that.  This change was necessary because some scripts were unable to detect git repositories when the `files.hidden` setting was false.  Excluding hidden files never worked properly in the past.  Clink v1.4.16 does its best to be as backward-compatible and forward-compatible as possible, but in some cases scripts may need to be updated to work properly when the settings or config variable are changed from their default values.
- Fixed the `match-hidden-files` config variable to work again (regression introduced in v1.0.0).  Also, when off, now it hides files and directories whose names begin with `.`.
- Fixed [#421](https://github.com/chrisant996/clink/issues/421); `clink.bat` errors with quoted arguments (regression introduced in v1.3.47).
- Updated documentation with more cross-referencing links for Clink settings, Readline commands, Readline config variables, and standard Lua APIs.

#### v1.4.15

- Added `log.getfile()` to get the current log file path.
- Fixed match display to better accommodate escape codes for italics and underline, if present and supported by the terminal.
- Fixed [#414](https://github.com/chrisant996/clink/issues/414); argument color doesn't reset for values in multi-column layout when `colored-stats` is `off`.
- PR [#418](https://github.com/chrisant996/clink/pull/418); Fix crash caused by destruction of non detached threads.
- PR [#417](https://github.com/chrisant996/clink/pull/417); Fix buffer overread caused by usage of strcmp on non null-terminated char arrays.

#### v1.4.14

- Fixed autosuggest to update again if matches are marked as volatile and the input line changed while matches were generated in the background (related to [clink-completions#164](https://github.com/vladimir-kotikov/clink-completions/issues/164)).

#### v1.4.13

- Added more status information in `clink-diagnostics` <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd>.
- Fixed quoting in the `insert-completions` <kbd>Alt</kbd>-<kbd>*</kbd> command.
- Fixed quoting for non-filename completions.
- Fixed a CPU busy-loop after `match_builder:setvolatile()` was called during an autosuggest strategy.
- Fixed [#411](https://github.com/chrisant996/clink/issues/411); setting `%CLINK_HISTORY_LABEL%` after Clink started didn't take effect (regression introduced in v1.3.18).

#### v1.4.12

- Additional improvements and logging for East Asian ambiguous width characters.
- Running `clink inject` no longer empties the log file, so that AutoRun doesn't result in the log file being cleared over and over, which interferes with diagnostic efforts.
- Fixed [#407](https://github.com/chrisant996/clink/issues/407); the `complete` command gets confused by `.` prefix on files.

#### v1.4.11

- Fixed [#406](https://github.com/chrisant996/clink/issues/406); the "lambdagenerated.omp.json" theme for Oh-My-Posh has problems in CJK codepages.  The [East Asian Ambiguous](https://www.unicode.org/reports/tr11-2/#:~:text=East%20Asian%20Ambiguous%20%28A%29%20-%20Characters%20that%20occur,sets%2C%20but%20also%20some%20of%20the%20mathematical%20symbols%29.) support has been rewritten to solve multiple subtle issues; the fix in v1.4.9 exposed other inaccuracies.

#### v1.4.10

- Added optional `level` argument to `log.info()` to facilitate more accurate reporting about the calling code.
- Fixed extra duplicate log entry when the updater finds that Clink is already up to date.
- Fixed [#405](https://github.com/chrisant996/clink/issues/405); vi search gives unexpected results (regression introduced in v1.4.7).
- Fixed [#402](https://github.com/chrisant996/clink/issues/402); for convenience, print the Clink Releases page URL after a successful update (takes effect on the next upgrade _after_ v1.4.10).

#### v1.4.9

- Improved the problematic character reporting in the `clink-diagnostics` command.
- Fixed measurements for the East Asian ambiguous width characters (this should solve the Cmder problems with lambda in the CMD.exe prompt text, including the space after the lambda).

#### v1.4.8

- Added `rl.needquotes()` function to check whether text needs quotes in a command line.
- Changed the `terminal.color_emoji` setting `auto` mode to more broadly support accurate width measurements for color emojis (regardless whether the terminal program is capable of actually drawing the color emoji).
- Now `clink-diagnostics` <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd> automatically analyzes the prompt text for problematic characters, reports them, and offers suggestions for how to solve problems they might be causing.
- Fixed the `completion` autosuggest strategy so it doesn't provide a suggestion that requires quoting if the command line input is not currently quoted.
- Fixed overly aggressive detection of color emojis (regression introduced in v1.4.7).

#### v1.4.7

- Clink now supports ARM64.
- Clink now recognizes when the terminal host is WezTerm.
- Clink now supports color emojis in Windows Terminal and WezTerm, according to the Unicode v15.0 standard.  The new `terminal.color_emoji` setting controls when Clink assumes the terminal supports color emojis (color emojis are rendered using double-width characters, which can interfere with cursor positioning math, so Clink needs to know whether the terminal supports color emojis).
- Enabled Readline's support for non-incremental vi-mode search (<kbd>N</kbd>, <kbd>n</kbd>) to search for a shell pattern using `fnmatch()`, as Posix specifies.
- Fixed obscure issue when a "luafunc:" macro modifies the input line and then invokes a completion command.
- Fixed `line_state:getword()` and `line_state:getendword()` to not strip quotes during `generator:getwordbreakinfo()` functions (regression introduced in v1.1.24).
- Fixed [#393](https://github.com/chrisant996/clink/issues/393); backward compatibility issue when `clink.arg.register_parser()` is passed something that is not a parser at all.
- Fixed [#111](https://github.com/chrisant996/clink/issues/111) again; `cd ..`<kbd>Tab</kbd> didn't complete to `..\` (regression introduced in v1.3.1).

#### v1.4.6

- Added a more informative exit code from `clink inject`.  It returns 0 if successful, 2 if a fatal error occurred, or 1 if a non-fatal error occurred (such as Clink was already present; related to [cmderdev/cmder#2800](https://github.com/cmderdev/cmder/issues/2800)).
- Fixed [#382](https://github.com/chrisant996/clink/issues/382); `%CLINK_PROFILE%` doesn't supersede `--profile` (regression introduced in v1.0.0).

#### v1.4.5

- Improved debug Lua messages; Clink's built-in Lua scripts reported "?" as the filename, and now they report "{filename.lua}".
- Fixed potential for a crash in `clink-help` when including unbound "luafunc:" macros for which custom descriptions have been provided (e.g. <kbd>Alt</kbd>-<kbd>4</kbd> then <kbd>Alt</kbd>-<kbd>H</kbd>).

#### v1.4.4

- Fixed the screen width in the Help commands and Completion commands (regression introduced in v1.3.43).
- Fixed to not load the same Lua script more than once from a completions directory when the Lua script doesn't define an argmatcher.
- Fixed architecture reported by `clink-diagnostics` <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd> (regression introduced in v1.3.49).

#### v1.4.3

- Added backward compatibility for obsolete `clink.quote_split()`, `clink.split()`, and `clink.get_screen_info()`.
- Fixed empty completion list when typing two letters in rapid succession when both the `autosuggest.enable` and `autosuggest.async` settings are enabled.

#### v1.4.2

- Fixed path abbreviation in some cases.

#### v1.4.1

- Added `os.abbreviatepath()` and `os.expandabbreviatedpath()`.
- Invoking completion expands abbreviated paths when the new `match.expand_abbrev` setting is enabled.
- Fixed displayed matches for `c:` or `c:dir\`.

#### v1.4.0

- Added `clink.getpopuplistcolors()` to get the default popup list colors.
- Added `clink.refilterafterterminalresize()` to enable automatic prompt refilter after terminal resize.  Prompt filters should only enable this if they're designed to refilter very quickly, otherwise they may cause responsiveness problems.
- The `clink.popuplist()` function allows the `items` table to include fields to override the height, width, colors, and direction of the list.
- The `clink_settings` file format has been relaxed slightly to accept trailing whitespace after a Boolean setting's value.  Note that manually modifying the `clink_settings` file is not supported; always use `clink set` to query or change Clink settings.
- Fixed an obscure crash in the Readline library inside the `reverse-search-history` command when pressing the first key of a multikey binding (e.g. <kbd>Ctrl</kbd>-<kbd>X</kbd>) and then pressing any key that does not follow the first key in any of the corresponding multikey bindings (e.g. <kbd>Esc</kbd>).
- Fixed leaked file handle when `history.save` is False.
- Fixed [#370](https://github.com/chrisant996/clink/issues/370); <kbd>Tab</kbd> inside `set /p var=` mistakenly discards any previous input.

#### v1.3.51

- Fixed `:setendofflags()`; it made `--` work correctly for input line coloring, but it didn't work correctly when generating match completions.
- Fixed obscure edge cases where matches returned by Lua scripts could display incorrectly in `clink-select-complete`, or could potentially even crash if Lua scripts returned invalid results from the `ondisplaymatches` or `onfiltermatches` events.

#### v1.3.50

- Fixed the prefix highlighting when displaying matches.

#### v1.3.49

- Autorun detects non-interactive CMD process earlier, before injecting the Clink DLL.  This can improve performance somewhat, and may be able to reduce spurious problems with antivirus tools (such as described in [#367](https://github.com/chrisant996/clink/issues/367)).
- Updater deletes zip file if it fails to unzip.  This can help automatically recover from a damaged zip download.

#### v1.3.48

- Fixed another [#356](https://github.com/chrisant996/clink/issues/356) case; trailing spaces at end of display were sometimes optimized away by mistake (regression introduced in v1.3.43).

#### v1.3.47

- Removed the message "Clink autorun is disabled by CLINK_NOAUTORUN".
- Fixed [#361](https://github.com/chrisant996/clink/issues/361); detect `%CLINK_NOAUTORUN%` faster.
- Fixed another [#356](https://github.com/chrisant996/clink/issues/356) case; end of display line not cleared sometimes (regression introduced in v1.3.43).

#### v1.3.46

- Fixed right-side prompts on Windows 8.1 (they never worked correctly on Windows 8.1).
- More fixes for [#356](https://github.com/chrisant996/clink/issues/356); input line display garbled on Windows 8.1 (regression introduced in v1.3.43).

#### v1.3.45

- Fixed the history expansion preview when the input line grows or shrinks to use a different number of screen rows.
- Fixed `"cd"` so it doesn't match the `cd` argmatcher, because CMD commands cannot be quoted.
- Fixed [#356](https://github.com/chrisant996/clink/issues/356); input line display garbled on Windows 8.1 (regression introduced in v1.3.43).

#### v1.3.44

- Fixed [#348](https://github.com/chrisant996/clink/issues/348); pasting in ConEmu or Windows Terminal duplicates the 2nd character (regression introduced in v1.3.43).

#### v1.3.43

- Added `clink.max_input_rows` setting that limits the number of screen rows to use for displaying the input line, scrolling as appropriate if the input line exceeds the limit.
- Added `color.histexpand` setting.  When this is configured with a color, then Clink highlights history expansions in the input line and shows a preview of the expansion that will be applied near the current cursor position.
- Added `history.auto_expand` setting.  When this is set to false, history expansions will not be performed automatically upon <kbd>Enter</kbd>, but they may still be performed by invoking expansion commands such as `clink-expand-history` <kbd>Alt</kbd>-<kbd>^</kbd>, or `clink-expand-line` <kbd>Alt</kbd>-<kbd>Ctrl</kbd>-<kbd>E</kbd>.
- When a coroutine error happens, write a Lua traceback to the log file.
- The `clink-diagnostics` command now reports costs for prompt filters and input line coloring classifiers when a numeric arg is given (e.g. <kbd>Alt</kbd>-<kbd>1</kbd> <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd>).
- Fixed the input line color when the command word is an alias _and_ a directory _and_ has an argmatcher (regression introduced in v1.3.40).
- Fixed how the inserted completion is highlighted while using `clink-select-complete` with the `match.substring` setting enabled.
- Fixed Readline bugs in the numeric arg input state;
  - Numeric arg overflow check was missing in certain cases.
  - Numeric arg input state could accidentally empty the prompt string.
  - Numeric arg input state accidentally continued showing the arg input message after using <kbd>Alt</kbd>-<kbd>-</kbd> while already in numeric arg input state.
- Fixed some minor input line coloring and completion mistakes for `clink set`.
- Fixed `quoted-insert` followed by <kbd>Esc</kbd>, so that it inserts the raw ESC character.
- Fixed how <kbd>Esc</kbd> is handled in isearch mode (e.g. <kbd>Ctrl</kbd>-<kbd>r</kbd>); it should terminate isearch without reverting the input line.
- Fixed `what-is` to consistently reset the color afterward.
- Fixed vi insertion mode when `terminal.raw_esc` is enabled, so that <kbd>Esc</kbd> changes to vi command mode.
- Fixed `clink.refilterprompt()` to report an error upon invalid usage (it cannot be used inside a prompt filter, as that could cause infinite recursion and a crash).
- Fixed [#344](https://github.com/chrisant996/clink/issues/344); `history` prints UTF8 text incorrectly.
- Fixed [#342](https://github.com/chrisant996/clink/issues/342); typing `foo.abc` doesn't recognize `foo.abc.cmd`.
- Fixed [#340](https://github.com/chrisant996/clink/issues/340); various display glitches in the Readline library (Clink now uses custom display routines instead of the Readline display routines).
- Fixed [#339](https://github.com/chrisant996/clink/issues/339); `%CD%` doesn't expand.

#### v1.3.42

- Added `console.checkinput()` to check whether input is available.
- Changed `console.readinput()` to accept an optional <span class="arg">no_cursor</span> argument to avoid changing cursor visibility or position.
- Fixed [#320](https://github.com/chrisant996/clink/issues/320); resizing the terminal can garble the prompt (`bash` has the same problem, so Clink now uses custom code to handle resizing the terminal).

#### v1.3.41

- Added `io.truncate()` to truncate a file.
- Added `string.comparematches()` to compare two matches; this is normally not needed because Clink automatically sorts matches, but some match generators may prefer to disable the automatic sorting and perform custom sorting.
- Added `rl.describemacro()` to associate descriptions with `luafunc:` macros (or any macro), to be shown in the `clink-show-help` and `clink-what-is` commands.
- The `clink.popuplist()` function now accepts a callback function to be invoked when <kbd>Del</kbd> is pressed.
- The `colored-completion-prefix` configuration variable now works with match display filtering, provided the display strings only prepend or append to the match strings.
- Removed the obsolete `clink.gui_popups` setting.
- Fixed the `completion-prefix-display-length` configuration variable in various cases.
- Fixed timing condition that could potentially crash (regression introduced in v1.3.40).

#### v1.3.40

- Clink now has an icon, and also includes some colored icons for color-coding your shortcut files, terminal tabs, and etc.
- Avoid mis-coloring a directory name as though it is an argmatcher (uses a background thread to stay responsive).
- Fixed command word completion after `:chaincommand()`.  Now <code>cmd /c&nbsp;</code><kbd>Tab</kbd> works properly.
- Fixed `:chaincommand()` to work properly in a nested argmatcher; it should imply `:nofiles()` otherwise it can pop out to the previous argmatcher instead of chaining.
- Fixed `cmd` argmatcher to only chain after the `/c` and `/k` flags, to more accurately match actual cmd.exe syntax.
- Fixed backward compatibility for argmatchers using the old v0.4.9 APIs with [functions as argument options](#argmatcher_functions) (regression introduced in v1.2.7).
- Fixed the `clink-select-complete` command with match display filtering.

#### v1.3.39

- "Use enhanced defaults" now includes history timestamps.
- Fixed delay while loading the history file when history timestamps are enabled (regression introduced in v1.3.18).
- Fixed suggestions to resume after fully accepting an input line suggestion and then changing the text (regression introduced in v1.3.29).
- Fixed reporting unbound commands in `clink-show-help` when arg is 4 (<kbd>Alt</kbd>-<kbd>4</kbd> <kbd>Alt</kbd>-<kbd>h</kbd>) (regression introduced in v1.3.9).
- Fixed to normalize path separators in a fully qualified pathname when using `clink.argmatcher(full_path)`.
- The documentation now shows a link icon when hovering over any heading or API name, to make it easy to copy and share links.

#### v1.3.38

- Added `clink.recognizecommand()` function that input line coloring classifiers can use to find whether to color a word as executable.  This is the same mechanism Clink uses internally, and the analysis is asynchronous.
- Now `clink.argmatcher(command)` may be passed a fully qualified pathname for <span class="arg">command</span> to enable different argmatchers for programs with the same name.
- Fixed argmatcher lookup to favor doskey aliases, so that e.g. "<code>dir</code>" can be aliased to an alternative program but "<code>&nbsp;dir</code>" can invoke the built-in dir command, and they can each have separate argmatchers.
- Fixed the `oncommand` event to also fire when the command word offset changes, because adding/removing a leading space can change whether the command is an alias, which can make the typed command word resolve to a different file or program to invoke.
- Fixed `line_state:getcommandoffset()` when the first word is quoted.
- Fixed `line_state` parsing for input lines such as `foo.exe&`, so that the `exec.enable` setting can generate matches properly.
- Fixed completion so that CMD command names are not among the completions when preceded by a quote.
- Fixed `color.argmatcher` color to not overwrite custom colors that may have already been applied.
- Fixed `^` to not be a word break character when parsing the input line.

#### v1.3.37

- When `argmatcher:addarg()` is passed a table containing <code>loopchars="<span class="arg">chars</span>"</code> then the <span class="arg">chars</span> are treated as delimiters for a single argument, and they do not move on to the next argument slot in the parser.
- Added `clink.parseline()` to parse a string into one or more `line_state` objects.
- Added `os.getdrivetype()` to get the drive type for a path; especially useful if your code needs to skip network paths.
- Added `match_builder:setvolatile()` to force the matches to be used only once.  This makes it possible for match generators to produce different kinds of matches based on what has been typed, e.g. an email address match generator could list user names until `@` is typed, and then list domain names.
- The `clink-diagnostics` command now lists registered argmatchers when the numeric arg > 1 (<kbd>Alt</kbd>-<kbd>2</kbd> <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd>).
- Rewrote the path parsing routines to properly respect UNC paths and `\\?\` syntax and `\\?\UNC\` syntax.
- Fixed `clink.print(NONL, etc)` to not print a TAB character after a `NONL` that is the first argument.
- Fixed [#329](https://github.com/chrisant996/clink/issues/329); file completions may be mistakenly marked as directories (regression introduced in v1.2.36; affects only backward compatibility mode).
- Fixed [#326](https://github.com/chrisant996/clink/issues/326); `rl.expandtilde()` doesn't have a way to expand tildes everywhere in an input line string.
- Fixed [#325](https://github.com/chrisant996/clink/issues/325); potential hangs while typing if `%PATH%` contains a UNC path.

#### v1.3.36

- Incremental search in `clink-popup-history` now centers the found item if it is scrolled out of view.
- Tilde expansion is supported for all Lua script directory names and for the `%CLINK_PROFILE%` environment variable (but there is a quirk, and for the profile directory tilde expands to `%LOCALAPPDATA%` for backward compatibility purposes).
- Fixed some tilde expansion issues; quotes weren't always recognized, and embedded tildes could in some cases result in malformed paths.
- Fixed semicolon delimiter in `%CLINK_COMPLETIONS_DIR%`.
- Fixed stack exhaustion crash when using `inject --profile nul`.
- Fixed detection of device names when coloring command words; a device name anywhere in a path is not a valid executable.

#### v1.3.35

- Fixed finding a `completions` directory under the profile directory.
- Fixed finding a `completions` directory under script directories set via `clink installscripts`.
- Fixed `clink.refilterprompt()` when the prompt wraps past the edge of the screen and a right-sided prompt string is present.
- Fixed `rl.getpromptinfo()` when the prompt wraps past the edge of the screen (the `promptline` and `inputline` fields were inaccurate).
- Fixed consistent sort order for completion matches that differ only by case.
- Fixed `undo` (<kbd>Ctrl</kbd>-<kbd>z</kbd>) after using `clink-reload` (bound by default to the sequence <kbd>Ctrl</kbd>-</kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>r</kbd>).  This also fixes `rl.ismodifiedline()` after `clink-reload`, which was causing clink-flex-prompt to show a modmark after `clink-reload`.
- Fixed [#321](https://github.com/chrisant996/clink/issues/321); incremental search not working in the `clink-popup-history` command (regression introduced in v1.3.19).
- Fixed [#320](https://github.com/chrisant996/clink/issues/320); prompt becomes garbled when prompt is updated by async prompt filters and wraps past the edge of the screen and a right-sided prompt string is present.

#### v1.3.34

- Improved error reporting in `lua.debug` mode for coroutine failures.
- Fixed argmatcher flag definitions that begin with `+` (regression introduced in v1.3.11).
- Fixed the updater when there are PowerShell configuration problems that cause internal errors unrelated to Clink's use of PowerShell.
- Fixed potential coroutine failure if a `delayinit` argmatcher is still running after a new input line begins (regression introduced in v1.3.29).
- Fixed `os.getfileattributes()`, `os.isfile()`, and `os.isdir()` to fail as intended when the input includes a wildcard (regression introduced in v1.1.0).
- Fixed potential Lua error when typing a command name that included a wildcard, if the wildcard matched a file in a `completions` directory (regression introduced in v1.3.23, due to the `os.getfileattributes()` issue above).

#### v1.3.33

- The `io.popenyield()` function now also returns a function that can be used to get the exit status from the command.
- Fixed `io.popenyield()` for some programs (such as FC and XCOPY) that fail to start if the stdin handle is empty.
- Fixed [#312](https://github.com/chrisant996/clink/issues/312); slow startup due to inefficiency in the updater check at startup (regression introduced in v1.3.26).

#### v1.3.31

- Reverted the v1.3.29 change to `file:close()` that returned the process exit state even after `io.popen()` or `io.popenyield()` in a coroutine.  It had subtle negative side effects.

#### v1.3.30

- Fixed the `menu-complete` family of commands for `fromhistory` argmatchers when `autosuggest.enable` is enabled.
- Fixed [#311](https://github.com/chrisant996/clink/issues/311); "The handle is invalid." (regression introduced in v1.3.29).

#### v1.3.29

- Fixed how <kbd>Right</kbd> and etc work after fully accepting an input line suggestion.  It shouldn't immediately show a new suggestion when the current suggestion is fully accepted (until the cursor is moved or the text changes), and `win-cursor-forward` shouldn't append characters from the previous command (e.g. when `clink.default_bindings` is `windows`).  Otherwise holding or double-pressing <kbd>Right</kbd> can accidentally turn into something the user didn't intend.
- Fixed double-loading completion script when a command word includes a path component (e.g. "c:\clink_dir\program.exe" mistakenly attempted to load "c:\clink_dir\program.lua" instead of loading "program.lua" from the completions directories).
- Fixed delayinit argmatchers so they don't get orphaned if a new input line starts before they finish.
- Fixed `file:close()` to be able to return the process exit state even after `io.popen()` or `io.popenyield()` in a coroutine.

#### v1.3.28

- Fixed [#309](https://github.com/chrisant996/clink/issues/309); some locales fail to parse the PowerShell version number.

#### v1.3.27

- Added more detailed logging when the updater fails.
- Added check to make sure PowerShell v5 is present when using `clink update`.
- Added `unicode.fromcodepage()` and `unicode.tocodepage()` for UTF8 conversions.  One of the cases where this can be useful is when handling redirected output from programs that product output using the current Active Code Page.

#### v1.3.26

- Added `unicode.iter()`, `unicode.isnormalized()`, and `unicode.normalize()` for more precise UTF8 string manipulation.
- The updater now includes an HTTP header to request no caching, in an effort to work around an issue on Win8.x.
- The updater now updates the version number displayed in the "Apps & features" section of Settings in Windows (or "Add or Remove Programs" in Control Panel in older versions of Windows).
- Fixed the `directories.dupe_mode` setting in `clink set`.
- Fixed the `remove-history` command when trying to remove a history entry added by the `add-history` command that hasn't yet been saved.
- Fixed the `/D=` flag in the setup program.
- Fixed potential double-load of scripts in the profile or binaries directories, due to an issue while searching `completions` directories (regression introduced in v1.3.24).
- Fixed potential infinite loop when merging an argmatcher with itself.
- Fixed potential accidental resume of an orphaned coroutine.
- Fixed potential double-reporting of coroutine errors when the `lua.debug` setting is enabled.
- Internal maintenance to the coroutine management system.

#### v1.3.25

- Fixed updater when `%TEMP%` contains spaces.
- Fixed executable file detection to color device names (such as nul, aux, con, lpt1, and com1) as neither recognized nor unrecognized.
- Fixed [#304](https://github.com/chrisant996/clink/issues/304); hang when typing device names (such as aux, con, lpt1, and com1) (regression introduced in v1.3.23).
- Fixed [#303](https://github.com/chrisant996/clink/issues/303); downloading latest update doesn't work on Windows 8.x.

#### v1.3.24

- Standardized the order in which `completions` directories are searched.
- Fixed the second return value from `clink.popuplist()`, which was backwards by mistake.

#### v1.3.23

- Automatically loads Lua completion scripts from `completions` directories.  This allows you to optionally store completion scripts (argmatcher scripts) in a separate directory from your other Lua scripts, so that completion scripts are only loaded when needed.  This can speed up Clink start time, if you have a large volume of argmatcher scripts.  See [Completion Directories](#completion-directories) for more information.
- Fixed `clink.oncommand()` when redirection appears on the command line before the command name (e.g. `>somefile command`).
- Fixed both parts of [#300](https://github.com/chrisant996/clink/issues/300); unable to find latest release zip file (incomplete fix in v1.3.22 by mistake).

#### v1.3.22

- When the `lua.debug` setting is enabled, any uncaught errors in coroutines are reported (and logged).
- Fixed edge case that could cause Windows Terminal to temporarily stop responding mouse input.
- Fixed [#300](https://github.com/chrisant996/clink/issues/300); unable to find latest release zip file.

#### v1.3.21

- Improved the auto-updater when there are multiple copies of Clink on a computer; it no longer needs to download the .zip update file multiple times.
- Fixed mouse input when the console is scrolled.
- Fixed [#299](https://github.com/chrisant996/clink/issues/299); update shown even though up to date.

#### v1.3.20

- Fixed potential crash in popup lists if there are only a few items (regression introduced in v1.3.18).
- Fixed [#296](https://github.com/chrisant996/clink/issues/296); on some computers closing CMD reports it's taking too long to close (the fix works around external issue).

#### v1.3.19

- Added `directories.dupe_mode` setting that controls how duplicates are handled in the directory history list for the `clink-popup-directories` command.
- Added <kbd>Del</kbd> to delete a directory entry in the `clink-popup-directories` command.
- Fixed obscure intermittent problem with `delayinit` argmatchers.
- Fixed <kbd>Ctrl</kbd>-<kbd>C</kbd> and <kbd>Ctrl</kbd>-<kbd>Break</kbd> in CMD built-in commands (regression introduced in v1.3.14).

#### v1.3.18

- Added a built-in updater for Clink, which is enabled by default.  When enabled, Clink reports when an update is available.  Run `clink update` to apply the update.
- Added `clink-insert-suggested-line`, `clink-insert-suggested-word`, `clink-insert-suggested-full-word`, and `clink-accept-suggested-line` commands (see [#280](https://github.com/chrisant996/clink/issues/280)).
- Added optional timestamps in the history file.  The new `history.time_stamp` and `history.time_format` settings control whether timestamps are saved and whether/how timestamps are shown.
- Added `cmd.altf4_exits` setting to control whether <kbd>Alt</kbd>-<kbd>F4</kbd> makes cmd.exe exit.  This is so that when the `terminal.raw_esc` setting is enabled pressing <kbd>Esc</kbd><kbd>Esc</kbd> behaves the same as <kbd>Alt</kbd>-<kbd>Ctrl</kbd>-<kbd>[</kbd> as expected, while still allowing <kbd>Alt</kbd>-<kbd>F4</kbd> to work.
- Added horizontal scrolling in the history popup list.
- Added `clink.onprovideline()` so scripts can register a function to be called after `onbeginedit` but before any input is processed.  The function can return a string to be executed as a command line, in which case the line editor is not invoked and the `onendedit` and `onfilterinput` events happen immediately (see [#263](https://github.com/chrisant996/clink/discussions/263)).
- Added `rl.gethistorycount()` and `rl.gethistoryitems()` to access the history items.
- Added `os.gettemppath()` to get the system temporary directory.
- Added `io.sopen()` to control sharing access when opening or creating a file.
- Both `io.open()` and `io.sopen()` support the `"x"` file mode modifier (combined with `"w"` or `"w+"`), which makes the function fail if the file already exists.
- Improved the `what-is` command to apply word wrapping to the command description.
- Fixed generating matches from history (`fromhistory=true`) in argmatchers (regression introduced in v1.3.13).
- Fixed executable file detection for file names that contain `+` characters.
- Fixed some input keys accidentally handled by the OS sometimes (regression introduced in v1.3.6; original fix was introduced in v1.2.10).
- Fixed timing conditions where other console programs could accidentally override Clink's mouse input mode.
- Fixed left mouse click in popup lists when `terminal.mouse_input` is enabled.
- Fixed alternate key bindings for copy (<kbd>Ctrl</kbd>-<kbd>Ins</kbd>) and paste (<kbd>Shift</kbd>-<kbd>Ins</kbd>).
- Fixed description column alignment in `clink.popuplist()`.
- Fixed keyboard driver for <kbd>Alt</kbd>-<kbd>Ctrl</kbd>-<kbd>[</kbd> when the `terminal.raw_esc` setting is enabled.
- Fixed keyboard driver for <kbd>Alt</kbd>-<kbd>Ctrl</kbd>-<kbd>]</kbd> and <kbd>Alt</kbd>-<kbd>Ctrl</kbd>-<kbd>\</kbd>.

#### v1.3.17

- Fixed coloring executable files in the input line (some file types weren't detected correctly, and missing files were considered executable if their extension had a file type association).
- Fixed a potential crash when coloring executable files in the input line (regression introduced in v1.3.16).
- Fixed [#281](https://github.com/chrisant996/clink/issues/281); screen height detected incorrectly (regression introduced in v1.3.16).

#### v1.3.16

- Added `os.sleep()`.
- Revised the Clink documentation to directly include the Readline documentation.
- Fixed executable file detection for file extensions that point at Progids instead of having a shell command.
- Fixed double help message from `history` command when invalid flags are used.
- Fixed crash when file permissions block accessing the history file, and the `history` command reports an error message accordingly.
- Fixed [#262](https://github.com/chrisant996/clink/issues/262); changing the terminal width between prompts (while a different program is running) caused Readline to start displaying the input line incorrectly.

#### v1.3.15

- Fixed [#269](https://github.com/chrisant996/clink/issues/269); reverse video could get confused (regression introduced in v1.3, and incompletely fixed in v1.3.4).

#### v1.3.14

- <kbd>Ctrl</kbd>-<kbd>Break</kbd> can now interrupt some operations, including match display and match generators and the `os.globfiles()` and `os.globdirs()` functions in Lua scripts.
- Added `os.issignaled()` so Lua scripts can cooperatively interrupt themselves.
- Improved responsiveness of completion commands when an async prompt filter is still running in the background (`io.popen()` and `os.execute()` are serialized in prompt filter coroutines, and are serialized separately in match generator coroutines, but are not serialized in other coroutines).
- Fixed displaying pasted lines.
- Fixed doskey aliases in pasted lines.
- Fixed [#268](https://github.com/chrisant996/clink/issues/268); crash when `copy` command prompts whether to overwrite a file (regression introduced in v1.3.13).

#### v1.3.13

- Argmatchers can use `:chaincommand()` to treat the rest of the command line as another command.
  - Added an argmatcher for `cmd` that uses `:chaincommand()`.
  - E.g. so that completion after `cmd program ` can be parsed by an argmatcher for `program` instead of `cmd`.
- Argmatchers can be more involved in parsing the command line, if they wish.  See [Responding to Arguments in Argmatchers](#responsive-argmatchers) for more information.
  - A callback function can be assigned to an argument position by including `onarg=your_callback_function` in the table given to `:addarg()`.
  - The `onarg` callback and match functions receive an additional `user_data` parameter.  When parsing begins, the `user_data` is an empty table, and your functions can set or get data from the table.  Each time a flag or argument links to another argmatcher, the new argmatcher gets a separate new empty `user_data` table.
  - The built-in `cd` and `pushd` argmatchers use this to influence match completion for the rest of the input line.  E.g. `pushd \foo & program `<kbd>Tab</kbd> uses `\foo` as the current directory when generating possible completions.
- Functions registered with `clink.onfilterinput()` may optionally return multiple lines in a table.
- Fixed completions for words that contain `.`, such as `clink set color.`<kbd>Tab</kbd> (regression introduced in v1.3.11).
- Fixed doskey macros that use `echo off $T ...`.
- Fixed input line coloring for a drive letter by itself.
- Fixed input line coloring for a file that exists but is not executable.
- Fixed obscure edge case with delayinit argmatchers and `operate-and-get-next`.
- Fixed potentially inconsistent input line coloring when `classifier:applycolor()` is given an escape code that sets only the foreground or background color.

#### v1.3.12

- Improved `clink-select-complete` to show inline descriptions as long as they don't require more than 9 rows to display the matches.
- Added second argument to the `delayinit` function for an argmatcher.
- Added `argmatcher:setflagsanywhere()` and `argmatcher:setendofflags()` to control where flags are recognized.
- Added `clink.getargmatcher()` to find the argmatcher for a command name or command line (`line_state`).
- Added `os.resolvealias()` to expand doskey alias(es) in a line of text.
- Added `clink.oncommand()` to register a function to be called when a command is entered in the edit line.
- Improved support for argmatcher non-flag argument values that end with `=`:  now they can have a linked argmatcher, and input line coloring is applied correctly.
- Fixed quotes during completion (regression introduced in v1.3.11).
- Fixed `cd /d dir` argmatcher (regression introduced in v1.3.11).
- Fixed input line coloring for `"echo"` and other CMD commands; quotes disqualify a word from being a CMD command.
- Fixed redundant argmatcher delayinit for flags.
- Various minor backward compatibility fixes.

#### v1.3.11

- Updated the list of recognized CMD command names.
- Better support for `(` and `)` when expanding doskey macros (e.g. now `( macro foo ) & ( macro bar )` works).
- Fixed word break characters during completion.  Only `=` `;` had ever worked before, and now the normal CMD completion word break characters work (including `,` `!` `+` `(` and many others).
- Fixed match display to not force a single column unless there are descriptions present.
- Fixed backward compatibility for `_argmatcher:add_arguments()` and `_argmatcher:set_arguments()` (they were mistakenly adding all the arguments into the first argument position).
- Fixed backward compatibility for merging argmatchers.
  - Merging argmatchers works again.  It is still a simple merge similar to v0.4.9, but it should be sufficient for common cases.
  - Fixed some bugs in how Clink v0.4.9 merged argmatchers (the unit tests for merging fail in v0.4.9).
  - Added support for some merging cases that weren't implemented yet in v0.4.9.
- And other obscure minor backward compatibility fixes.

#### v1.3.10

- An argmatcher can extend itself on the fly, when needed.  For example, if it needs to parse arguments and flags from `--help` text, or if the available command arguments change based on the current directory, or etc.  See [Adaptive Argmatchers](#adaptive-argmatchers) for more information.
- Recognizes `^` and environment variables when coloring the command word, and when navigating by typing a directory name by itself.
- Added input line coloring for the `rem` command.
- Fixed memory corruption (regression introduced in v1.3.1).
- Fixed input line coloring for `clink set setting value & another command`.
- Fixed argmatcher input line coloring for matches using the `{ match="abc" }` syntax.
- Fixed finding an argmatcher after `(` at the beginning of the line.
- Fixed mouse clicks in `clink-select-complete` to insert the clicked match, in addition to highlighting it.
- Fixed [#252](https://github.com/chrisant996/clink/issues/252); `md` and `rd` should complete more than 1 argument.

#### v1.3.9

- When `argmatcher:addarg()` is passed a table containing `fromhistory=true` then additional matches are generated by parsing the history file to find values for that argument slot from commands in the history file.
- Added `clink.reclassifyline()` which triggers input line coloring and redisplays the input line.  This is intended for use by a coroutine that has made changes that will affect input line coloring.
- Added `match_builder:isempty()`.
- Added mouse horizontal wheel support in `clink-select-complete`.
- Added back the `_argmatcher:setflagprefix()` function.
- Loading Lua scripts now reports any syntax errors when the `lua.debug` setting is enabled.
- Incorporate Lua 5.2.4 (minor patches to the Lua language).
- Report a warning if the profile directory is configured to point at a file.
- AutoRun is selected by default again in the installer (reverted change from v1.3.5).
- The `terminal.raw_esc` setting now also address the same kind of problem with <kbd>Alt</kbd>-<kbd>[</kbd> and <kbd>Alt</kbd>-<kbd>Shift</kbd>-<kbd>O</kbd> as with the <kbd>Esc</kbd> key.
- Fixed when an argmatcher adds nested tables of matches using the `{ match="abc" }` syntax, so that the nested matches are added recursively and properly suppress adding a space after argument matches that end with `:` or `=`.
- Fixed when `match_builder:addmatch()` and `match_builder:addmatches()` add nested tables of matches using the `{ match="abc" }` syntax, so that the nested matches are added recursively.
- Fixed when `match_builder:addmatch()` and `match_builder:addmatches()` add an `"arg"` match type, so that they automatically suppress appending a space after matches that end with `:` or `=` (the behavior was documented, but did not work correctly).
- Fixed `remove-history` so that it updates the history offset correctly and subsequent editing operations affect the correct undo list.
- Fixed obscure issues in how certain key binding patterns were reported by `clink-show-help` and `dump-functions`.
- Fixed how `clink echo` reports <kbd>Ctrl</kbd>-<kbd>Backspace</kbd> and <kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>Backspace</kbd>.
- Fixed [#249](https://github.com/chrisant996/clink/issues/249); sending keystrokes from WScript does nothing for some keys.
- Fixed [#244](https://github.com/chrisant996/clink/issues/244); installer did not detect previous installation directory (regression introduced in v1.3.5; the fix takes effect on the next install _after_ an install with the fix).

#### v1.3.8

- Added `terminal.mouse_modifier` setting and `%CLINK_MOUSE_MODIFIER%` environment variable; these can override the modifier keys that activate Clink mouse input.
- Added `%CLINK_SETTINGS%` environment variable; this can override the directory where the `clink_settings` file is located.  This can be used to put it in a directory that syncs between computers, for example.
- During `clink-select-complete` <kbd>Ctrl</kbd>-<kbd>Home</kbd> or <kbd>Ctrl</kbd>-<kbd>End</kbd> select the first or last match.
- When `argmatcher:addarg()` is passed a table containing `nosort=true` then the matches are unsorted (displayed in the order listed in the table).
- The .zip file now contains `_default_settings` and `_default_inputrc` so that they do not take effect unless manually renamed to remove the `_` name prefix.  This avoids changing the defaults unexpectedly.
- Fixed mouse click+drag in the input line (it accidentally behaved like double click+drag).
- Fixed the selection highlight width in `clink-select-complete` when some matches have descriptions but some do not.
- Fixed `argmatcher:addargunsorted()` to turn off sort.
- Fixed [#239](https://github.com/chrisant996/clink/issues/239); crash when <kbd>F7</kbd> and <kbd>Del</kbd>.

#### v1.3.7

- Mouse click+drag now works.
- Mouse click below `clink-select-complete` list expands the list instead of dismissing it.
- Fixed responding to mouse clicks when the terminal's scrollback buffer is not empty (it only worked in Windows Terminal).
- Fixed [#237](https://github.com/chrisant996/clink/issues/237); installer does not maintain previously selected "Autorun when cmd.exe starts" (regression introduced in v1.3.5).

#### v1.3.6

- Added `terminal.mouse_input` setting; the default is `auto`.  `auto` lets mouse input work in ConEmu, or in the default Conhost terminal when Quick Edit mode is unchecked in the console Properties dialog.  See the documentation for more information.
- Added `cua-select-word` command that selects the word at the cursor.
- <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd> with a numeric argument always includes registered Lua match generators, prompt filters, etc even when the `lua.debug` setting is off.
- Fixed potential for a coroutine to have extra delays sometimes when continuing past the end of one edit line, and into the next edit line.
- Fixed a potential busy loop when the command word is unrecognized.
- Fixed Quick Edit mode in plain Conhost windows; it had always been disabled (I never noticed because I always configure console windows to disable it anyway).

#### v1.3.5

- Raised default `history.max_lines` to 10000.
- Added an optional `default_inputrc` file:
  - It is loaded from the profile directory, or from the binaries directory.
  - It uses the same format as the `.inputrc` file, and is loaded immediately before the `.inputrc` files.
  - It has the effect of superseding built-in default values for  Readline configuration variables and key bindings; any settings in the `.inputrc` supersede those in the `default_inputrc` file.
- The installer has a new "Use enhanced default settings" option which installs `default_settings` and `default_inputrc` files to provide default values that activate more of the Clink enhancements (to give a more enhanced experience "out of the box").
- The installer no longer defaults to installing AutoRun.
- The installer no longer has an option to use versioned install directory; files are installed directly in the install directory.
- Added `clink.runcoroutineuntilcomplete()` which allows a coroutine to keep running past the end of one edit line, and into the next edit line.
- Fixed `os.execute()` return values when run in a coroutine (regression introduced in v1.3.2).
- Fixed the selection color in `clink-select-complete` when `colored-stats` is off.
- Fixed problems when displaying matches that exceed the screen width.
- Fixed [#231](https://github.com/chrisant996/clink/issues/231); installer fails sometimes when uncheck "Use versioned install directory".

#### v1.3.4

- Pressing <kbd>Del</kbd> or <kbd>Ctrl</kbd>-<kbd>D</kbd> in a command history popup deletes the selected history entry.
- Changed the default color for directory match completions to bright yellow (bright blue is hard to see).
- Added an argmatcher for `history`.
- Added an optional `default_settings` file:
  - It is loaded from the profile directory, or from the binaries directory.
  - It uses the same format as the `clink_settings` file, and the values in it supersede the built-in default values for settings.
  - Settings are now saved if they are set (vs cleared by `clink set setting.name clear`), even if the set value matches the default value.
- Minor performance improvement when calculating columns widths when `match.fit_columns` is enabled.
- Fixed accidentally using only one column in `clink-select-complete` when there are 9 or fewer matches and none of them have description text (regression introduced in v1.3.3).
- Fixed <kbd>Shift</kbd>-<kbd>Right</kbd> to accept the next full word of the suggestion without clearing the rest of the suggestion (regression introduced in v1.3.3).
- Fixed terminal emulation for the reverse video escape codes (this also fixes the right border color of the selected item in popup lists).
- Fixed buffer overrun in Readline `yank-last-arg` when the previous command ends in a backslash.
- Fixed the Readline History library to not apply Unix style backslash escaping in CMD (e.g. in `program subdir\ text` there are 3 arguments; the `\ ` is not an escaped space).
- Fixed crash when displaying matches and `match.fit_columns` is enabled and the terminal width is greater than 150 characters.
- Fixed potential busy loop during idle (until a key is pressed) in certain cases (regression introduced in v1.3.3).
- Fixed the emulated terminal color conversions from 8-bit and 24-bit.
- Fixed cursor style when using `clink` to start a new command window from inside a Windows Terminal window.
- Fixed quirk when using Clink file completion to complete a directory name for `clink --profile \foo\`, so that the path doesn't end up malformed.
- Fixed a memory leak.

#### v1.3.3

- Match completion display calculates column widths to fit the most columns on the screen.  Can be controlled by the `match.fit_columns` and `match.limit_fitted_columns` settings.
- Match descriptions are right-justified when more than one column is displayed, to help more columns fit.
- When multiple columns of matches are displayed with descriptions, the descriptions are bracketed with parentheses for readability and accessibility purposes.
- <kbd>F1</kbd> in `clink-select-complete` toggles between showing descriptions at the bottom vs with the matches.
- Added `match.substring` setting that uses a substring search for completions if none are found with a prefix search.
- Added `color.executable` and `color.unrecognized` settings.  When set, these cause the command word (the first word) to be colored if it is recognized as an executable file, or is not recognized as a command, doskey macro, directory, argmatcher, or executable file.  Lookups are asynchronous for optimum responsiveness while typing.
- Argmatchers can hide certain flags (e.g. synonyms) by using `argmatcher:hideflags()`.
- Argmatchers can disable sorting matches by using `argmatcher:addargunsorted()` or `argmatcher:addflagsunsorted()`.
- Generators can disable sorting matches by using `match_builder:setnosort()`.
- Fixed duplicated closing quote in `clink-select-complete`.
- Fixed display of non-directory matches that contain slashes, such as git branch names (regression introduced in v1.3.1).
- Fixed match display filtering in `clink-select-complete` (regression introduced in v1.3.1).
- Fixed the `insert-comment` command (regression introduced in v1.2.44).
- Fixed sorting flag completions so that all `-` flags precede any `--` flags.
- Fixed a couple of memory leaks, and added memory tracking system to more easily catch leaks.
- Various minor fixes in `clink-select-complete`.

#### v1.3.2

- Added <kbd>Shift</kbd>-<kbd>Space</kbd> as a recognized key.  By default it is bound to `clink-shift-space`, which invokes whatever is bound to the normal <kbd>Space</kbd> key, so that it continues to behave as before unless you specifically bind something else to the <kbd>Shift</kbd>-<kbd>Space</kbd> key.
- Added `clink-magic-suggest-space` command which inserts the next full suggested word (if any) up to a space, and then inserts a space.  Binding this to <kbd>Shift</kbd>-<kbd>Space</kbd> can be very handy.
- Added `cmd.admin_title_prefix` setting that can replace the "Administrator: " console title prefix.
- When loading settings, if there is no setting file yet then Clink looks for a `default_settings` file in the binaries directory and uses that to initalize the settings.
- Added `CLINK_TERM_VE` and `CLINK_TERM_VS` environment variables that can be set to override the normal (insert mode) and enhanced (overwrite mode) cursor styles, respectively.
- Various minor fixes to how the cursor style is updated; the visible bell now works in Windows Terminal.
- When `os.execute()` is used in a coroutine, it automatically yields until complete.
- Fixed async match generators (during autosuggest) to be allowed to finish, instead of getting canceled on every keystroke if they hadn't finished yet.
- Fixed cursor blink, which was accidentally disabled (regression introduced in v1.2.44).
- Fixed the `win-cursor-forward` command so it doesn't trigger generating a new suggestion if there isn't already one.

#### v1.3.1

- Added `autosuggest.async` setting (on by default) that lets suggestions generate matches asynchronously to stay responsive while typing.
- Added `match.max_rows` setting that limits the number of rows `clink-select-complete` can use.
- Added `match.preview_rows` setting that makes `clink-select-complete` show the specified number of rows of matches as a preview, and expands to show the full set of matches when the selection moves past the preview rows (similar to completion in the fish shell).
- Added `color.comment_row` setting that chooses the color for the comment row in `clink-select-complete`.  The comment row shows the "and <em>N</em> more matches" or "rows <em>X</em> to <em>Y</em> of <em>Z</em>" messages.
- Changed arrow keys in `clink-select-complete` to wrap on both horizontal and vertical edges (similar to the fish shell).
- Changed arrow keys in `clink-select-complete` at the beginning and end of the list to wrap to the other end based on the `menu-complete-wraparound` config variable.
- Match generators can now specify an append character (or suppress appending) on a per-match basis.
- The `clink-diagnostics` command lists prompt filters, generators, classifiers, and suggesters when a numeric argument is given (e.g. <kbd>Alt</kbd>-<kbd>1</kbd> <kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd>).
- The `os.globdirs()` and `os.globfiles()` functions now automatically yield periodically if used inside a coroutine.
- The `io.popen()` function now automatically yields periodically if used in read mode (the default) inside a coroutine.
- The `io.popenyield()` function now automatically falls back to `io.popen()` if used outside a coroutine.
- Fixed input line coloring to operate on only the input line, not including the suggestion.
- Fixed display when typing to filter `clink-select-complete` (regression introduced in v1.2.49).
- Fixed display of `clink-select-complete` when the current match changes the number of visible lines in the edit buffer.
- Fixed displaying matches when only a drive letter is entered.
- Fixed [#216](https://github.com/chrisant996/clink/issues/216); Long escaped URLs do not display correctly in a prompt.

#### v1.3

- Added back `mark-modified-lines` support (was removed in v1.2.36).
- Added `rl.ismodifiedline()` function so prompt filters can show a modified line indicator if they wish.
- Added `autosuggest.original_case` setting (on by default) that controls whether parts of the line are updated to use the suggestion's original capitalization, or to keep the typed capitalization.
- Added `terminal.east_asian_ambiguous` setting that controls how the width is determined for the [East Asian Ambiguous](https://www.unicode.org/reports/tr11-2/#:~:text=East%20Asian%20Ambiguous%20%28A%29%20-%20Characters%20that%20occur,sets%2C%20but%20also%20some%20of%20the%20mathematical%20symbols%29.) range of characters (which includes the lambda character).  This may help with working around display issues in some terminal hosts.
- Added help descriptions for many vi mode commands.
- Improved relevance of `completion` suggestions by suppressing them when the word at the cursor is empty.
- The `:suggest()` function on suggesters can now return a suggestion string and an offset where the suggestion begins in the input line.
- Fixed a limitation in Readline so that `completion-prefix-display-length` and `colored-completion-prefix` can coexist.
- Fixed when temp files from `io.popenyield()` get deleted.  They were lingering until Lua garbage collection, but they can be deleted almost immediately.
- Fixed the order of initialization:  first the Readline .inputrc config file is loaded, and then Lua scripts are loaded.  This enables Lua scripts to reliably override Readline config variables if they wish (for example so a prompt filter can clear `emacs-mode-string` and print its own keymap indicator as part of the prompt).
- Fixed transient prompt to not show keymap mode strings or the modified line mark.
- Fixed vi mode key bindings that can accept suggestions.
- Fixed missing `vi-undo` command; it was pre-bound to some keys but could not be bound to any other keys.
- Fixed the "show help" commands when listing unbound commands:  unbound vi mode commands should not be listed in emacs mode because the vi mode commands are only meant to be used in vi mode, and are not meant to be bound to custom keys.
- Fixed memory leak in suggestions.

#### v1.2.50

- Added `rl.insertmode()` function to get or set whether insert mode is active.
- Added `clink.onaftercommand()` so scripts can register a function to be called after every input command (key binding).
- Added additional failure logging during `clink inject`.

#### v1.2.49

- Added `cua-previous-screen-line` and `cua-next-screen-line`, bound to <kbd>Shift</kbd>-<kbd>Up</kbd> and <kbd>Shift</kbd>-<kbd>Down</kbd>, to extend the text selection up/down by one screen line.
- Updated match generator for `clink set autosuggest.strategy` to list the available suggestion generators.
- The `clink-show-help` and `clink-popup-show-help` commands can include commands that aren't bound to any key, when the numeric argument is 4 (e.g. <kbd>Alt</kbd>-<kbd>4</kbd> then <kbd>Alt</kbd>-<kbd>H</kbd>).
- The `rl.getkeybindings()` function takes an optional `mode` argument to control sorting and whether to include commands that aren't bound to any key.
- Generating suggestions skips generating match completions when the current word looks like a UNC path.  This avoids pauses while typing that would otherwise occur when accessing networked drives.
- Fixed <kbd>Alt</kbd>-<kbd>Right</kbd> so it accepts the next word of the suggestion, just like <kbd>Ctrl</kbd>-<kbd>Right</kbd> does.
- Fixed the `clink-paste` command so it sets the mark to the cursor point prior to pasting.
- Fixed when `history.dupe_mode` is "erase_prev" and `history.shared` starts true but changes to false; subsequent commands were not added to the history properly anymore in that session (regression introduced in v1.1.0).
- Fixed [#210](https://github.com/chrisant996/clink/issues/210); `clink-select-complete` drawing bug with RPROMPT.

#### v1.2.48

- <kbd>Ctrl</kbd>-<kbd>Right</kbd> now inserts the next word of the suggestion the same way it would move to the next word, and <kbd>Shift</kbd>-<kbd>Right</kbd> inserts the next full word of the suggestion up to a space.
- Keys like <kbd>Home</kbd>/<kbd>End</kbd>, <kbd>Shift</kbd>-<kbd>Left</kbd>/<kbd>Right</kbd>, and <kbd>Ctrl</kbd>-<kbd>Left</kbd>/<kbd>Right</kbd> work in VI mode.
- Fixed input line coloring glitch when color settings use the `sgr` syntax.

#### v1.2.47

- Added autosuggestions similar to the Fish shell.
  - Turn on by running `clink set autosuggest.enable true`.  See the `autosuggest.enable` and `autosuggest.strategy` Clink settings for details.
  - Added `clink.suggester()` function to create new suggestion generators that can be used in the `autosuggest.strategy` setting.
- The `clink-diagnostics` command also lists match generators registered by `clink.generator()`.
- Fixed the color when the `horizontal-scroll-mode` config variable is `on`.
- Fixed the transient prompt when using Help commands.
- Fixed the `clink autorun` commands when paths contain Chinese characters and the system code page isn't UTF8.
- Fixed [#209](https://github.com/chrisant996/clink/issues/209); `clink-popup-show-help` command fails.
- Fixed [#208](https://github.com/chrisant996/clink/issues/208); orphaned symlinks are colored wrong.
- Fixed [#203](https://github.com/chrisant996/clink/issues/203); unable to inject when Clink binary directory contains Chinese characters (regression introduced in v1.0.0).

#### v1.2.46

- Added a `magic-space` command that performs history expansion on the text before the cursor point and then inserts a space.  Note: this is slightly different than one in bash, which performs history expansion on the whole line and can end up inserting the space in a wrong spot.
- Added `rl.getbinding()` and `rl.setbinding()` functions to query or override key bindings.
- Added a `clink.refilterprompt()` function to invoke prompt filtering on demand.
- The `clink-popup-directories` command is now bound by default to <kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>PgUp</kbd>.
- The `clink-select-complete` command is now bound by default to <kbd>Ctrl</kbd>-<kbd>Space</kbd>.
- Fixed the `clink-popup-history` command so incremental search works again (regression introduced in v1.2.36).
- Fixed messages sometimes not being erased when finished, e.g. when using <kbd>Alt</kbd>-<kbd>digits</kbd> (regression introduced in v1.1.11).
- Fixed potential for prompt to redraw incorrectly after showing help when the `prompt.transient` setting is enabled.
- Fixed settings defined by Lua scripts so that the Lua scripts can reliably see the current values even while the Lua scripts are being loaded or reloaded.

#### v1.2.45

- Clarified description of the `match.wild` Clink setting.
- Fixed [#196](https://github.com/chrisant996/clink/issues/196); installer checkboxes not working properly.

#### v1.2.44

- Fixed `clink.ondisplaymatches()` so it receives the right match strings (regression introduced in v1.2.39).
- Fixed [#194](https://github.com/chrisant996/clink/issues/194); argmatcher not found when command name contains a dash (regression introduced in v1.1.5).
- Fixed [#176](https://github.com/chrisant996/clink/issues/176); use current installation dir when upgrading clink.  Now the installer remembers the chosen installation directory and defaults to the same place when installing an upgrade (all of the checkbox states are remembered, in fact).
- Fixed [#171](https://github.com/chrisant996/clink/issues/171); have a way to override install directory.  Now the installer has a checkbox whether to install to a versioned directory (recommended).  Unchecking the box installs program files to a `bin` subdirectory, instead of the usual versioned subdirectory.

#### v1.2.43

- Fixed lingering issues with non-ASCII characters in path names in Clink (follows up on the preceding fixes for non-ASCII user name characters).

#### v1.2.42

- Fixed potential for history file to get corrupted during compacting, if multiple Clink instances are running concurrently.
- Fixed `clink inject` when the user account name contains non-ASCII characters (regression introduced in v1.0.0).
- Fixed [#193](https://github.com/chrisant996/clink/issues/193); consider removing the 50K history limit:  The `history.max_lines` Clink setting once again supports 0 to mean unlimited.  Note that as the history file grows larger, it takes longer to load.  If the size becomes a problem, you can use `clink history compact <n>` to prune the history file to N items as well as compacting it (removing deleted items).
- Fixed [#192](https://github.com/chrisant996/clink/issues/192); completing `~` by itself does nothing:  Completing `~` by itself now inserts the %USERPROFILE% directory.  This is different than bash, because on Windows it doesn't make sense for ~ by itself to complete other user accounts.  This is a convenient way to expand tilde into a path that Windows understands.
- Fixed [#191](https://github.com/chrisant996/clink/issues/191); `cd /d -` isn't supported:  The `cd -` feature now supports `cd /d -` as well.  It also supports `cd -` even if there is a doskey macro defined for `cd`.

#### v1.2.41

- Fixed [#187](https://github.com/chrisant996/clink/issues/187) differently:  `doskey.enhanced` is `true` by default again, but if a macro contains `$*` or `$1`...`$9` tags within quotes then `|` and `&` symbols are part of the arguments, not command separators (and expansion stops after that macro).
- Fixed compatibility when `doskey.enhanced` is `false`; `alias|whatever` should not expand `alias` because there is no space after it.
- Fixed doskey expansion when `>&` redirection symbol is present; `command >& alias` should not attempt to expand `alias` because it's a redirection file name, not a command.

#### v1.2.40

- Fixed display quirks when an empty `display` or `description` string is provided by a match generator.
- Fixed [#187](https://github.com/chrisant996/clink/issues/187); the `doskey.enhanced` setting interferes with some macros (regression introduced in v1.0.0).  The setting is now `false` by default, because of the incompatibilities it can cause.

#### v1.2.39

- Fixed regression in match display filtering when listing possible completions (regression introduced in v1.2.38).
- Fixed display quirks in the `clink-select-complete` command when descriptions are at the bottom.

#### v1.2.38

- Enhancements for match descriptions (which are displayed when listing possible completions):
  - Argmatchers can provide description strings for flags and/or args (e.g. "Verbose output" for `-v`, or "Do nothing" for `-n`, etc).
  - Argmatchers can also provide argument info strings for flags and/or args.  These are hint strings, and not part of the completion match itself.  E.g. "linenum" for `--line`, which gets displayed as "--line linenum" when listing possible completions, but only "--line" is inserted.
  - Match generators can provide `display` and `description` strings when adding matches (`match_builder:addmatch()` and `match_builder:addmatches()`) -- it is no longer necessary to use `clink.ondisplaymatches()`.
  - The `clink-select-complete` command now shows match descriptions in a single line at the bottom (instead of in a second column) when there are more than 9 matches.
  - Added `color.arginfo` Clink setting for the arguments for a flag or argument when listing possible completions.
  - Added `color.description` Clink setting for the default match description color when listing possible completions.
  - Truncate descriptions when a line will wrap (or has wrapped) when listing possible completions.
- Command separators (`&`, `|`) and redirection symbols (`<`, `>`, `>&`) are colored in the input line, using colors from the new `color.cmdsep` and `color.cmdredir` Clink settings.
- Fixed <kbd>Backspace</kbd> in `clink-select-complete`; it had sometimes missed expanding the set of matches accordingly.
- Fixed the `clink-popup-history` command to respect the `search-ignore-case` setting.
- Fixed `:nofiles()` to dead-end an argmatcher (regression introduced in v1.0.0).
- Fixed `clink.ondisplaymatches()` and `clink.onfiltermatches()` when there's only 1 match.
- Fixed incremental find, find next, and find previous in console text popup lists.
- Fixed backward compatibility for the old matching filtering API.
- Fixed several other minor issues with match display filtering.
- Fixed intermittent incorrect match generation for `/flag:` or `/flag=` flags.
- Fixed duplicate removal with deprecated match generators.
- Fixed when nested deprecated argmatchers are exhausted (regression introduced in v1.2.36).
- Fixed deprecated match generators to not infer whether matches are filenames, to match the behavior of the v0.4.9 API.
- Fixed how `match.wild` works with deprecated match generators; e.g. arg completions for [z.lua](https://github.com/skywind3000/z.lua) weren't working (regression introduced in v1.1.5).
- Fixed argmatcher for `clink --profile` so it produces directory matches.
- Fixed `%CLINK_RPROMPT%` alignment when `color.prompt` is set.

#### v1.2.37

- Fixed [#180](https://github.com/chrisant996/clink/issues/180); `rl.collapsetilde()` behaves erratically.
- Fixed [#179](https://github.com/chrisant996/clink/issues/179); incorrect handling for certain keys on some keyboard layouts.
- Fixed [#178](https://github.com/chrisant996/clink/issues/178); OneDrive folders mistakenly show up as symlinks.
- Fixed [#177](https://github.com/chrisant996/clink/issues/177); be silent about autorun injection into TCC.

#### v1.2.36

- Added `win-history-list` command bound to <kbd>F7</kbd> by default.  This shows the history list, and executes the selected history entry.
- Changed all of the popup list commands to show popups using console text rather than GUI windows.
    - Added a `color.popup` Clink setting for the popup colors.  If not set, the console's popup colors are used.
    - Added a `color.popup_desc` Clink setting for the popup colors for the description column(s).  If not set, a color is chosen to complement the console's popup colors.
    - Added a `clink.gui_popups` Clink setting that can be set to use GUI popup windows as before (the `color.popup` settings have no effect on GUI popup windows).
- Key bindings now support <kbd>Enter</kbd> plus combinations of the <kbd>Ctrl</kbd>, <kbd>Shift</kbd>, or <kbd>Alt</kbd> modifier keys.
- Added more backward compatibility shims.
- Fixed the `clink-select-complete` command when `print-completions-horizontally` is on (and also minor issues when it is off).
- Fixed the `clink-select-complete` command when a Lua script has used `rl.setmatches()` to provide a custom list of matches.
- Fixed the `clink-menu-complete-numbers` family of commands (regression introduced in v1.2.32).
- Fixed a situation where the scrolling keys could stop working (regression introduced in v1.2.24).
- Fixed flags at the end of a linked parser, and fixed args at the end of two or more nested linked parsers (regression introduced in v1.0.0).
- Fixed [#172](https://github.com/chrisant996/clink/issues/172); add a choice in the installer to not add Start menu shortcuts.
- Fixed [#129](https://github.com/chrisant996/clink/issues/129); Bug completing files with - or _ characters (regression introduced in v1.0.0).

#### v1.2.35

- Added `rl_buffer:getanchor()` to get the text selection anchor (there is no set function; use `rl.invokecommand()` to invoke commands to set/extend the selection if needed).
- Reverted back to using IAT hooking (see issue #169).
- Fixed CUA selection commands invoked by `rl.invokecommand()`.
- Fixed [#170](https://github.com/chrisant996/clink/issues/170); directory symlink completion is truncated when `mark-directories` is `off` in the .inputrc file.
- Fixed [#169](https://github.com/chrisant996/clink/issues/169); incompatibility between AutoHotkey, AnsiCon, and Clink when all three are used in CMD's AutoRun regkey (regression introduced in v1.2.33).

#### v1.2.34

- Changed "luafunc:" macro functions to receive the `line_state` as a second argument.
- Fixed <kbd>Right</kbd> when `clink.default_bindings` is `windows`.
- Fixed `exec.files` setting so completion works when a path is specified (e.g. `subdir\foo`) (regression introduced in v1.2.33).
- Fixed [#158](https://github.com/chrisant996/clink/issues/158); crash when a keyboard macro contains `\015` (regression introduced in v1.0.0).

#### v1.2.33

- Rewrote how Clink hooks APIs in CMD.EXE; it no longer uses any IAT hooking, and exclusively uses Detours.
- Added `clink.default_bindings` Clink setting to choose between `bash` or `windows` default key bindings.  `bash` key bindings are still the default, for compatibility with existing Clink installations.
- Added `exec.aliases`, `exec.commands`, and `exec.files` Clink settings to further customize how matches are generated for the first word when the `exec.enable` Clink setting is enabled.
- Small performance optimization in the hooked `WriteConsoleW()` system API.
- Added logging for rare error case during inject.
- Added default key bindings for <kbd>F1</kbd> through <kbd>F9</kbd> that mimic the default Windows console function key inputs.
- Added `clink-selectall-conhost` command that mimics the default Windows console Select All command.
- Fixed `clink-select-complete` to remove duplicate matches if generators try to add duplicate matches.
- Fixed script error when `%PATH%` is not set and `exec.enable` and `exec.path` are both enabled.
- Fixed some quirks when using the `quoted-insert` command.

#### v1.2.32

- Added `rl_buffer:setargument()` function for a "luafunc:" macro to be able to set Readline's numeric argument.
- Added `os.getclipboardtext()` and `os.setclipboardtext()` functions.
- Added extra defense against antivirus interference (if it interferes when Clink inspects the target process, but permits Clink to inject into the target process).
- Fixed cooperation between "luafunc:" macros and CUA selection commands (e.g. <kbd>Shift</kbd>-<kbd>End</kbd>).
- Fixed `rl_buffer:getcursor()` and the return value from `rl_buffer:setcursor()`; both returned one less than the actual cursor position.
- Fixed [#162](https://github.com/chrisant996/clink/issues/162); clink completion shows script error (regression introduced in v1.2.31).

#### v1.2.31

- Added `clink uninstallscripts --all` to clear all script paths installed by `clink installscripts`.
- Added `os.touch()` function to set the access and modified times for a file.
- Added more fields in `os.globdirs()` and `os.globfiles()` when `extrainfo` is requested.
- **Potential Breaking Change:** Fixed `os.globdirs()` and `os.globfiles()` to only return extra info when actually requested (regression introduced in v1.1.8).
    - This unfortunately changes the scheme and may break some scripts if they requested no extra info, but used the extra info anyway.
- Fixed crash in `clink-select-complete` when a match display filter returns nil.
- Fixed `ondisplaymatches()` which was receiving one fewer matches than it should (related to [#124](https://github.com/chrisant996/clink/issues/124)).
- Fixed `ondisplaymatches()` which was not using the word break info correctly (from generators' `:getwordbreakinfo()` functions).
- Fixed `word_classifications:applycolor()`; the input line didn't necessarily refresh correctly after a custom classifier applied custom colors.
- Fixed potential stray inaccurate colorations when coloring the input for `clink set color.something some_value`.
- Fixed [#161](https://github.com/chrisant996/clink/issues/161); `clink installscripts` garbles previously-installed script paths when installing a new one.
- Fixed [#155](https://github.com/chrisant996/clink/issues/155); `settings.set()` doesn't update the settings file.

#### v1.2.30

- Replaced the built-in Lua implementation of `os.clock()` so it doesn't stop working after the program has been running for more than 24 days (which caused asynchronous prompt filtering to stop working).  As a side effect, the new `os.clock()` has microsecond precision instead of millisecond precision.
- Fixed coroutine throttling.  It was meant to prevent running more than once per 5 seconds, but accidentally forced running every 5 seconds, even if the coroutine was registered to run less often.

#### v1.2.29

- Added `prompt.transient` Clink setting which can collapse prior prompts to a condensed form.  The new `%CLINK_TRANSIENT_PROMPT%` and `%CLINK_TRANSIENT_RPROMPT%` environment variables supply the initial prompt strings, and prompt filters can define `:transientfilter()` and `:transientrightfilter()` functions to filter the transient prompt.
- Added `clink.logo` Clink setting to globally control what startup logo is shown (full copyright logo by default, or a short version logo, or no startup logo).
- Added `console.readinput()` function which waits for one key input, and returns the key sequence string for the key.
- Added `clink.reload()` function which reloads Lua scripts and the Readline config file at the next prompt.
- Added logging for more possible failure points while injecting Clink into the host process.
- Added default key bindings for <kbd>Ctrl</kbd>-<kbd>Up</kbd> and <kbd>Ctrl</kbd>-<kbd>Down</kbd> to scroll the screen one line, like conhost normally does.
- Now `clink set cl*` lists all settings that begin with `cl` (the star wildcard is only supported at the end of the string).
- Documentation includes a link to the new [clink-flex-prompt](https://github.com/chrisant996/clink-flex-prompt).
- Fixed the Lua debugger to support printing UTF8 text, and to escape string variable contents to avoid escape code side effects.
- Fixed [#154](https://github.com/chrisant996/clink/issues/154); crash when `settings.set("some_setting", false)` is used.
- Fixed [#153](https://github.com/chrisant996/clink/issues/153); ESC key problem.  Clink migrated the old `esc_clears_line` setting backwards, causing <kbd>Esc</kbd> to behave opposite from what was expected.
- Fixed [#152](https://github.com/chrisant996/clink/issues/152); LUA debugger breaks on the wrong line, and fails to execute expressions.

#### v1.2.28

- Added `rl.getpromptinfo()` function.
- Fixed loading .inputrc so that only one is loaded (regression introduced in v1.0.0a0 by the fix for [mridgers #258](https://github.com/mridgers/clink/issues/258)).  If similar behavior is still desired, consider using the `$include` directive in the Readline init file, to load additional files.
- Fixed `clink-select-complete` to respect when `mark-directories` in .inputrc file is `off`.
- Fixed crash in `console.findline()` when no attributes are passed.  Callers using v1.2.27 and earlier can work around the crash by passing `{}` for attributes.
- Fixed an off-by-1 bug in `console.scroll("absolute", top)`.  This will fix edge case malfunctions in some callers, but some callers could experience this as a breaking change.

#### v1.2.27

- The `cmd.get_errorlevel` Clink setting is now enabled by default.
- Clink now expands `$` codes in `%CLINK_RPROMPT%` before running prompt filters.
- Fixed parsing `2>&1` style redirection symbols, so the `&` doesn't get treated as a command separator.
- Fixed argmatchers to generate file matches for redirection arguments; `app.exe >` should generate file matches for the `>` symbol, not matches for the `app` argmatcher's first argument.

#### v1.2.26

- Fixed input line coloring for doskey aliases that don't have an argmatcher (regression introduced in v1.2.16).
- Fixed <kbd>Space</kbd> during `clink-select-complete` when there were already opening and closing quotes present.
- Fixed redrawing multiple lines of input after certain commands such as `clink-show-help` <kbd>Alt</kbd>-<kbd>H</kbd> (regression introduced in v1.1.20).
- Fixed the `completion-auto-query-items` config variable to account for multiple lines of input, if present.
- Fixed potential race condition if multiple Clink instances try to get the last errorlevel at the same time.

#### v1.2.25

- Added `cua-select-all` command to select the entire input line.
- Added `edit-and-execute-command` command to invoke an editor on the current input line and then execute the results (<kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>e</kbd>).  This attempts to invoke `%VISUAL%`, `%EDITOR%`, or `notepad.exe` as the editor, in that order.
- Added some new expansion commands:
    - `clink-expand-history` performs history expansion on the current input line (<kbd>Alt</kbd>-<kbd>^</kbd>).
    - `clink-expand-history-and-alias` performs history and doskey alias expansion on the current input line.
    - `clink-expand-line` performs history, doskey alias, and environment variable expansion on the current input line (<kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>E</kbd>).
- Added some new completion commands:
    - `glob-complete-word` performs wildcard completion on the text before the cursor point, with a `*` implicitly appended (<kbd>Alt</kbd>-<kbd>G</kbd>).
    - `glob-expand-word` inserts all the wildcard completions that `glob-list-expansions` would list (<kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>*</kbd>).
    - `glob-list-expansions` lists the possible wildcard completions of the text before the cursor point (<kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>g</kbd>).
- Added some command name synonyms for increased .inputrc file portability with bash:
    - `alias-expand-line` is a synonym for `clink-expand-doskey-alias`.
    - `history-expand-line` is a synonym for `clink-expand-history`.
    - `history-and-alias-expand-line` is a synonym for `clink-expand-history-and-alias`.
    - `insert-last-argument` is a synonym for `yank-last-arg`.
    - `shell-expand-line` is a synonym for `clink-expand-line`.
- Added a `match.expand_envvars` Clink setting to expand environment variables in a word before performing completion (for [mridgers #476](https://github.com/mridgers/clink/issues/476)).
- Changed the `match.wild` Clink setting to apply to all completion commands.
- Changed default key binding <kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>e</kbd> to the `clink-expand-line` command (not the key binding expands everything, instead of only the env var at the cursor).
- Removed default key binding <kbd>Alt</kbd>-<kbd>Shift</kbd>-<kbd>h</kbd> for the `clink-show-help-raw` command (it has only niche usefulness).
- Removed unintended VI mode key binding <kbd>Alt</kbd>-<kbd>Ctrl</kbd>-<kbd>h</kbd>.
- Fixed <kbd>Ctrl</kbd>-<kbd>Shift</kbd>-<kbd>2</kbd> and <kbd>Ctrl</kbd>-<kbd>Shift</kbd>-<kbd>6</kbd> (regression introduced in v1.1.39).
- Fixed `More?` continuation prompt when pasting multiple lines.
- Fixed `/flag:` and `/flag=` handling quirks, especially when trying to complete an environment variable in `/flag:%env`.
- Fixed quirks about environment variable expansion in the `clink-expand-env-var` command and the `os.expandenv()` function.

#### v1.2.24

- Added support for `%CLINK_RPROMPT%` to show a right side prompt, and for prompt filters to define a `:rightfilter()` function to filter the right side prompt.
- Fixed `clink-select-complete` to not append a space after a flag that ends with `:` or `=` (e.g. `/x:`).

#### v1.2.23

- Fixed <kbd>PgUp</kbd> and <kbd>PgDn</kbd> in the `clink-select-complete` command, under certain conditions where they don't navigate in the intended manner.
- Cosmetic change: better key names for <kbd>Enter</kbd> vs <kbd>Ctrl</kbd>-<kbd>m</kbd>, and <kbd>Alt</kbd>-<kbd>Bkspc</kbd> vs <kbd>Alt</kbd>-<kbd>Ctrl</kbd>-<kbd>h</kbd>, depending on the `terminal.differentiate_keys` setting.

#### v1.2.22

- Added `clink-what-is` command bound by default to <kbd>Alt</kbd>-<kbd>?</kbd>, which shows the key binding for the next key sequence that is input.
- Added `rl.getargument()` function to get the accumulated Readline numeric argument, if any.  For use in "luafunc:" macros.
- The `clink-show-help` command now categorizes key bindings and shows a description for the commands.  Using a numeric argument can control whether categorization and descriptions are used.
- Fixed invoking `clink-select-complete` while it is already active, so that it doesn't lose quotes around the current match if it has quotes.
- Fixed `clink-show-help` to list "Enter" instead of "C-m" for the <kbd>Enter</kbd> key.  Otherwise there's no way to differentiate between <kbd>Enter</kbd> and <kbd>Ctrl</kbd>-<kbd>M</kbd> when the `terminal.differentiate_keys` setting is enabled.
- Fixed the `insert-comment` command, which accidentally fell back to inserting `#` after the first prompt (that's what bash inserts, and shouldn't be used in Clink).
- Fixed the `dump-functions` command, which accidentally didn't list UTF8 key sequences correctly.

#### v1.2.21

- Fixed backwards exit codes from `clink autorun` commands.
- Fixed alert message text on startup when `debug.log_terminal` is set to true.
- Fixed [#143](https://github.com/chrisant996/clink/issues/143); crash on start when `terminal.raw_esc` is true (regression introduced in v1.2.19).

#### v1.2.20

- Added `os.debugprint()` function to print debug text via the OS `OutputDebugString()` API.
- Enabled match completion coloring even when using match display filtering.
- Fixed input of slash and backslash in non-directory completions when using the `clink-select-complete` command.
- Fixed match display filtering in the `clink-select-complete` command.
- Fixed match display filtering in the `clink-popup-complete` command.
- Fixed quirk from Readline where it sometimes displays one fewer columns of matches than actually fit on the screen.

#### v1.2.19

- Added `clink-select-complete` command which shows an interactive list of possible completions.
- Added terminal emulation for CGI G, CSI s, and CSI u sequences.
- Fixed column alignment for match display filtering when some characters take more than one cell to display.

#### v1.2.18

- Added completions for `clink installscripts` and `clink uninstallscripts`.
- Added support for Readline's coloring and marking of symlinks.
- Fixed `clink installscripts --help`.
- Fixed `clink-popup-directories` for directories with spaces.

#### v1.2.17

- Added `clink-popup-show-help` command to show popup list with searchable list of key bindings and invoke the selected key binding.
- Added `clink.popuplist()` function to show a popup list.  Only usable from inside a "luafunc:" key binding.
- Incremental search in the popup list window now centers the found item so items above and below it are visible.
- Fixed potential internal error when a doskey alias starts with `$` (regression introduced in v1.2.16).
- Fixed potential infinite loop when the `cmd.auto_answer` setting is enabled but an error occurs while retrieving a language string (might be related to [#137](https://github.com/chrisant996/clink/issues/137)).

#### v1.2.16

- **Breaking Change:** The `clink.onendedit()` Lua event has been split into two separate events:
    - `clink.onendedit()` registers a function to be called when the edit prompt ends.
    - `clink.onfilterinput()` registers a function to be called after the edit prompt ends (and after the onendedit event is sent), and the function can replace the input text.
- Added `rl.getkeybindings()` function to get a table containing key bindings.  The bindings can be invoked via `rl.invokecommand()`.  For example, a "luafunc:" macro could use this to get key bindings, show an interactive list, and then invoke the selected key binding.
- Fixed [#134](https://github.com/chrisant996/clink/issues/134); `print()` can stop working.  Issue [#93](https://github.com/chrisant996/clink/issues/93) can potentially happen any time redirection is used, so the fix must be applied repeatedly (not just after Clink injection).
- Fixed [#119](https://github.com/chrisant996/clink/issues/119); reuse registered parsers for doskey macros.

#### v1.2.15

- Fixed [#132](https://github.com/chrisant996/clink/issues/132); multiline prompt gets overwritten when resizing the terminal width (regression introduced in v1.2.14).

#### v1.2.14

- Automatically runs `clink_start.cmd` from the binaries directory and/or the profile directory when Clink is injected.
- Clink is able to retrieve the last exit code for use by Lua scripts.
    - The new `cmd.get_errorlevel` setting is off by default, but when enabled it retrieves the last exit code from CMD before running Lua scripts.
    - The new `os.geterrorlevel()` function gets the last exit code (or 0 if the setting is off).
    - It works by running a hidden command line between each interactive prompt (as if you typed `echo %errorlevel%` yourself every second command you type).  If you experience problems with this, turn it off.
- Improved refreshing the input line when resizing the terminal window.  It's better than before, but there's no way to make it work perfectly because Windows can resize the terminal further while a program is already trying to respond to the terminal having been resized previously.
- Fixed [#130](https://github.com/chrisant996/clink/issues/130); doskey alias completions stop working when there are many aliases.

#### v1.2.13

- Added support for linking a parser to flags ending with `:` or `=`; now completion works for the flag's argument.

#### v1.2.12

- Improved diagnostic output for coroutines (<kbd>Ctrl</kbd>-<kbd>x</kbd> <kbd>Ctrl</kbd>-<kbd>z</kbd>), plus more diagnostic info when the `lua.debug` setting is enabled.
- Fixed potential for a script error when a coroutine gets skipped due to a new prompt starting.

#### v1.2.11

- Added `clink.print()` function which behaves like `print()` but with support for ANSI escape codes (and terminal emulation), and also a `NONL` special argument that suppresses the usual newline at the end of the output.
- Expanded the sample code for async prompt filtering to clarify some things.
- Fixed [#126](https://github.com/chrisant996/clink/issues/126); allow <kbd>Esc</kbd> to input literal escape character.
    - The new `terminal.raw_esc` setting controls how <kbd>Esc</kbd> input works.
    - Added migration for the old `esc_clears_line` setting.

#### v1.2.10

- Added asynchronous prompt filtering -- scripts can use this to do work in the background (e.g. `git status`) and refresh the prompt when finished.
    - Added `clink.promptcoroutine()` function to allow a prompt filter to do some work in the background.
    - Added `io.popenyield()` function to allow a coroutine to yield until the command's complete output is ready.
    - Added `prompt.async` setting that can disable asynchronous prompt filtering if preferred.
- Log error codes for failures during `clink inject`.
- Clarified help text for `clink autorun` (per [#122](https://github.com/chrisant996/clink/issues/122)).
- Documentation clarifications and reorganization.
- Fixed `clink` and `history` aliases getting lost after exiting a nested Clink instance.
- Fixed some input keys accidentally handled by the OS after certain Lua code is run.
- Fixed [#124](https://github.com/chrisant996/clink/issues/124); `onfiltermatches()` receives one fewer matches than it should.
- Fixed [#123](https://github.com/chrisant996/clink/issues/123); Failed to inject (Host validation failed).
- Fixed [#117](https://github.com/chrisant996/clink/issues/117); Setup causes "System Error".

#### v1.2.9

- Added detection for possible antivirus interference when injecting Clink.
- Ignore duplicate scripts paths when loading scripts.
- Fixed [#118](https://github.com/chrisant996/clink/issues/118); inputrc is not read from state directory (regression introduced in v1.0.0).

#### v1.2.8

- Fixed `...\` or `.../` to change directories (path separator after several dots).
- Fixed `/dirname/` to change directories (forward slashes when a directory is the only thing in the input line).
- Fixed [#114](https://github.com/chrisant996/clink/issues/114); "Clink already loaded in process" error when autorun is installed for both Current User and All Users.
- Fixed [#113](https://github.com/chrisant996/clink/issues/113); forward slash translation didn't work with the `cd` command.

#### v1.2.7

- Fixed [#113](https://github.com/chrisant996/clink/issues/113); `clink.slash_translation()` had been removed (regression introduced in v1.0.0).
    - The new `match.translate_slashes` setting controls the default behavior for slash translation for completion matches.
    - The new `clink.translateslashes()` API can override slash translation for completion matches (and `clink.slash_translation()` is supported for backward compatibility).

#### v1.2.6

- Fixed tilde expansion for directory by itself; now `~\` can change the working directory to the `~` directory.
- Fixed pagination when displaying completions that take more than 1 line to display.
- Fixed inserting directory match completions when a Lua script didn't include a trailing path separator in the directory match.
- Fixed [#111](https://github.com/chrisant996/clink/issues/111); `..` completion is different from bash (regression introduced in v1.0.0).

#### v1.2.5

- Added `os.expandenv()` function to expand environment variables in a string.
- Added `console.cellcount()` function to count the cells a string will use when displayed.
- Added `console.plaintext()` function to remove ANSI escape codes from a string.
- Clink now sets `%=clink.bin%` that points to the Clink binaries directory.  This can be particularly useful for a portable installation of Clink so that scripts can find the Clink binaries directory and construct relative paths to other nearby files.
- Clean up column alignment in `--help` texts.
- Fixed `history.sticky_search` with anchored history search.
- Fixed `clink inject --profile` to use correct log file name while initially injecting.
- Fixed Clink autorun to be more compatible with Cmder ([Cmder #2536](https://github.com/cmderdev/cmder/issues/2536)).

#### v1.2.4

- Added support for <kbd>Shift</kbd>-<kbd>Arrows</kbd> to select text and typing to replace selected text.
- Added optional argument to `word_classifications:classifyword()` and `word_classifications:applycolor()` to allow only applying color where another color hasn't yet been applied.
- Fixed first <kbd>Up</kbd> after reusing a history line so that it gets the reused history line, rather than getting the previous history line.
- Fixed `add-history` command to not add blank lines to history.
- Fixed `rl.setmatches()` (regression introduced in v1.1.26).
- Fixed input coloring for `clink set` and any color setting name (regression introduced in v1.2).
- Fixed potential crash with `clink history --session`.
- Fixed <kbd>Ctrl</kbd>-<kbd>D</kbd> when `cmd.ctrld_exits` is disabled; it didn't exit, but it did still discard the input line and start a new prompt.
- Fixed [#107](https://github.com/chrisant996/clink/issues/107); autorun reports inject failures (regression introduced in v1.2.3).
- Fixed [#106](https://github.com/chrisant996/clink/issues/106); history missing `--bare` option (regression introduced in v1.2.3).

#### v1.2.3

- Added `history.sticky_search` setting:  when enabled, reusing a history line does not add the reused line to the end of the history, and it leaves the history search position on the reused line so next/prev history can continue from there (e.g. replaying commands via <kbd>Up</kbd> several times then <kbd>Enter</kbd>, <kbd>Down</kbd>, <kbd>Enter</kbd>, etc).
- Added failure reporting and logging when `clink inject` fails.
- Added `--unique` flag for use with `clink history compact --unique` to remove duplicate entries from the history list.
- The `clink-popup-complete` command now matches wildcards.
- Restored the <kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>U</kbd> key binding from v0.4.9 (moves the current working directory up one level).
- Fixed searching for inputrc files to also search in the profile directory (regression introduced in v1.0.0).
- Fixed incremental search in the History popup list to search in reverse order (bottom to top).
- Fixed `clink-popup-history` to set the history search position like other history search commands do, so that it plays well with the `history.sticky_search` setting.

#### v1.2.2

- Added `%CLINK_HISTORY_LABEL%` environment variable to use a different master history file (fixes [#99](https://github.com/chrisant996/clink/issues/99)).

#### v1.2.1

- Added Troubleshooting Tips section in the documentation.
- Added backward compatibility for `clink set` with v0.4.9.  Old setting names and values are not documented, but are automatically mapped to the appropriate new setting(s).  This was done so that suggestions in old web sites and posts can usually continue to work, to reduce confusion and support burden.
- Fixed [#97](https://github.com/chrisant996/clink/issues/97); VS2017 error C2039: 'min': is not a member of 'std'.
- Fixed [#96](https://github.com/chrisant996/clink/issues/96); wrong setting string (the name of a setting was accidentally truncated).
- Fixed some slightly inaccurate/incomplete migration from old settings to new settings.

#### v1.2

- First official release from [chrisant996/clink](https://github.com/chrisant996/clink) fork.

#### v1.1.49

- Added `clink.classifier()` to enable coloring the input line independently from argmatchers.
- Added `word_classifications:applycolor()` to apply SGR escape codes anywhere in the input line.
- Removed `word_classifications:iswordclassified()`.
- Fixed the Product Version string in the binary file version resources.

#### v1.1.48

- Added `clink.getansihost()` function to get Clink's best guess who will process ANSI escape codes (can be useful for avoiding 256 bit and 24 bit color codes, for example).
- Added detection for being hosted in ConsoleZ.
- Fixed [#20](https://github.com/chrisant996/clink/issues/20); `set /p VAR=""` shows the normal command prompt text instead of empty prompt text.

#### v1.1.47

- Added default key binding for <kbd>Ctrl</kbd>-<kbd>Space</kbd> to invoke `old-menu-complete`, which is the most similar to CMD's standard <kbd>Tab</kbd> behavior.
- Fixed `search-ignore-case` config variable to be on by default.

#### v1.1.46

- Added `rl.setvariable()` to temporarily override the value of a Readline config variable.
- The completion commands now also expand tilde by itself (`~`), in addition to tilde followed by a path separator (`~\etc`).
- Fixed [#94](https://github.com/chrisant996/clink/issues/94); setting `history.save` to False also disables interactive history in subsequent sessions.

#### v1.1.45

- Fixed [#93](https://github.com/chrisant996/clink/issues/93); stdout is sometimes broken by Cmder init.bat.

#### v1.1.44

- Added `clink.getsession()`.
- Added `%CLINK_NOAUTORUN%` which overrides automatic inject when Clink is installed for autorun.
- Fixed [#92](https://github.com/chrisant996/clink/issues/92); `clink-popup-history` and similar commands not working with ConEmu and Cmder (regression introduced in v1.1.25).

#### v1.1.43

- Added `clink history --diag` flag that prints diagnostic information while performing history operations.
- Minor optimization in `clink history` when printing the full list of history items.
- Fixed `clink history compact` so it actually performs compaction.

#### v1.1.42

- Added `clink history --bare` flag to omit history item numbers.
- Added several Lua functions:
    - `io.popenrw()` is like `io.popen()`, but returns both a read file handle and a write file handle (see documentation for important usage warning).
    - `os.createtmpfile()` creates a unique named temporary file, with control over the prefix and suffix and path.
    - `os.getfullpathname()` to get the full path name for a file.
    - `os.getlongpathname()` to get the long path name for a file.
    - `os.getshortpathname()` to get the 8.3 short path name (if available) for a file.
- Improved argument validation for Clink's Lua APIs.  This could expose bugs in existing scripts, so there is also a `lua.strict` setting that can be disabled to revert back to loose argument validation.
- Updated documentation.
- Fixed `clink history compact` so that it forces compaction as intended.
- Fixed completion for `clink set` so that filename completion works in string settings.
- Fixed backwards return value from `rl.invokecommand()`.
- Fixed console input/output modes across "luafunc:" key bindings, in case the Lua functions spawn a process that alters the console mode without restoring it.

#### v1.1.41

- Added `terminal.adjust_cursor_style` setting as a workaround to avoid interfering with the Windows 10 Cursor Shape console setting.  There are several trade-offs, though.
- Added `rl_buffer:refreshline()` function to redraw the input line, e.g. in case something has written over it.
- Added `os.getpid()` function to get the process ID, intended mainly to help salt unique resource names.
- Added `clink.onfiltermatches()` so scripts can register a callback function to run after Clink generates matches and before it displays them.

#### v1.1.40

- Added a group of `clink-complete-numbers` commands that do completion for numbers from the console screen, bound to <kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>N</kbd> by default.
- Added `rl.getlastcommand()` function that returns the name of the last command invoked by key bindings.
- Fixed sort order in <kbd>Alt</kbd>-<kbd>H</kbd> for the newly supported key bindings (that were added in v1.1.39).
- Fixed <kbd>Ctrl</kbd>-<kbd>Space</kbd> (regression introduced in v1.1.39).
- Fixed various <kbd>Ctrl</kbd>-<kbd>Shift</kbd>-<kbd>whatever</kbd> combinations (regression introduced in v1.1.39).
- Fixed `rl.setmatches()` when the input line is not empty and `clink.colorize_input` is enabled.

#### v1.1.39

- Added support for many more key bindings, such as <kbd>Ctrl</kbd>-<kbd>Shift</kbd>+Letter keys.
- Added `terminal.differentiate_keys` setting that when enabled allows binding <kbd>Ctrl</kbd> + <kbd>H</kbd> or <kbd>I</kbd> or <kbd>M</kbd> or <kbd>[</kbd> separately from <kbd>Backspace</kbd>, <kbd>Tab</kbd>, <kbd>Return</kbd>, or <kbd>Escape</kbd>.
- Removed `terminal.modify_other_keys` setting and made it always enabled.
- Changed `terminal.use_altgr_substitute` to be disabled by default so that <kbd>Ctrl</kbd>-<kbd>Alt</kbd> key bindings can work by default on keyboards with <kbd>AltGr</kbd>.
- Changed output from `clink echo` so it's directly usable in the inputrc files.
- Fixed `terminal.use_altgr_substitute` to only affect <kbd>AltGr</kbd> substitute key combinations (it had always broken the <kbd>RightAlt</kbd> key in general on other keyboard layouts).
- Fixed a benign issue with the console input mode in `clink echo`.

#### v1.1.38

- Fixed [#84](https://github.com/chrisant996/clink/issues/84); added `terminal.use_altgr_substitute` setting.
- Fixed [#80](https://github.com/chrisant996/clink/issues/80); clink.log is not deleted when Cmder injects Clink.

#### v1.1.37

- Fixed copy to clipboard (it never cleared the clipboard!).
- Fixed [#82](https://github.com/chrisant996/clink/issues/82); added two new `clink.paste_crlf` modes: `ampersand` replaces newlines with ampersands, and `crlf` pastes newlines as-is and executes any commands ending in a newline.
- Fixed [#69](https://github.com/chrisant996/clink/issues/69); space in the prompt disappears after enter echo: added support for CJK codepages.

#### v1.1.36

- Fixed [#79](https://github.com/chrisant996/clink/issues/79); Issue with United States - international keyboard layout (regression introduced in v1.1.0).
- Fixed [#78](https://github.com/chrisant996/clink/issues/78); crash when history file contains a line longer than 8192 characters (regression introduced in v1.1.2-alpha).

#### v1.1.35

- Fixed when the `mark-directories` inputrc variable is `off` (regression introduced in v1.1.1-alpha).
- Fixed Lua reading from stdin, especially in the Lua debugger (regression introduced in v1.1.25).
- Fixed exponential cost performance bug in Readline when removing duplicate matches.

#### v1.1.34

- Fixed copying to clipboard (CF_UNICODETEXT was put on the clipboard correctly, but CF_TEXT was empty and should have been omitted to let Windows automatically convert it from the Unicode text).

#### v1.1.33

- Make the "replacing arglink" warning message a little more informative, and write a lua traceback to the Clink log file.
- Fixed [#77](https://github.com/chrisant996/clink/issues/77); with ConsoleZ scrolling does not always work.
- Fixed [#76](https://github.com/chrisant996/clink/issues/76); cannot `cd` up multiple directories normally.

#### v1.1.32

- Added support for non-standard escape codes to set the window title or print environment variables.  Depending on the `terminal.emulation` setting, the behavior is slightly different.  When `emulate` Clink processes the escape codes.  When `native` with ConEmu (and Clink) the escape codes are passed to ConEmu, except that Clink processes the environment variable codes in prompt strings.  When `native` with other terminals, Clink preprocesses the title and environment variable escape codes in prompt strings, but passes the escape codes to the terminal outside of prompt strings.
- Fixed [#67](https://github.com/chrisant996/clink/issues/67); AutoRun interferes with Cmder.

#### v1.1.31

- Fixed [#74](https://github.com/chrisant996/clink/issues/74); clink gets confused by non-standard ConEmu escape codes.
- Fixed [#73](https://github.com/chrisant996/clink/issues/73); `exec.space_prefix` and other settings defined in Lua scripts don't take effect until second input line (regression introduced in v1.1.4).

#### v1.1.30

- Fixed history compacting on x86 (regression introduced in v1.1.2-alpha).

#### v1.1.29

- Added `clink installscripts` and `clink uninstallscripts` to make it easy for package managers like Scoop to install/uninstall script packages for use with Clink.  The installed script paths are stored in the registry for the current user.
- Fixed `bold` vs `bright` colors to more accurately follow generally accepted ANSI escape code conventions:
    - Renamed `dim` to `nobold` for clarity (though `dim` is still recognized for backward compatibility).
    - `bold` adds intensity to a non-intense color (e.g. `cyan` which is 36).
    - `nobold` removes intensity added by `bold` (e.g. `1;36` becomes `36`), but does not remove intensity from an explicit intense color (such as `bright cyan` which is `96`).
- Fixed support for `--file=` flags in argmatchers.
- Fixed match display filtering on the first try for a word (regression introduced in v1.1.19).
- Fixed the `clink --profile` flag (regression introduced in v1.1.10).
- Fixed `clink info` to accurately report the script dirs (it didn't account for the `clink.path` setting correctly).

#### v1.1.28

- Renamed the `log.rl_terminal` setting to `debug.log_terminal`; it has already been repeatedly very useful in multiple was since it was added, so it stays.
- Fixed [#70](https://github.com/chrisant996/clink/issues/70); ctrl+c not working (regression introduced in v1.1.25).

#### v1.1.27

- Added `color.argmatcher` setting which, when set, is used to color a command name if it has an associated argmatcher (this supersedes `color.cmd`, `color.doskey`, and `color.input`).  By default it's not set.
- Added `log.rl_terminal` setting which logs all terminal input and output for Readline (this setting may be renamed or removed in the future).

#### v1.1.26

- Added `rl.invokecommand()` which can invoke a Readline command from inside a "luafunc:" key binding.
- Added `rl.setmatches()` which can override match completions from inside a "luafunc:" key binding.
- Worked around UTF8 key binding problem with Readline which had been causing some meta key bindings (M-x, M-C-x, etc) to sometimes produce garbled key bindings and garbled entries in `clink-show-help` (<kbd>Alt</kbd>-<kbd>H</kbd>).
- Fixed crash if "luafunc:" key binding macro refers to a symbol that doesn't exist.

#### v1.1.25

- Added `clink-find-conhost` command that, when in a default (conhost) console window, is equivalent to picking "Find..." from the system menu.
- Added `clink-mark-conhost` command that, when in a default (conhost) console window, is equivalent to picking "Mark" from the system menu.
- `clink-copy-word` now copies the current word by default, but copies the nth word if a numeric argument is entered (see "Readline Arguments" in the Readline manual).
- Fixed match display filtering to not exceed the screen width (regression introduced in v1.1.12).
- Fixed multi-key sequences; in some cases it could get confused about whether an input key is part of a multi-key binding sequence (regression introduced in v1.1.1-alpha).
- Fixed stray input processing by conhost (holding <kbd>Ctrl</kbd>-<kbd>A</kbd> or <kbd>Ctrl</kbd>-<kbd>F</kbd> or etc could accidentally trigger conhost's shortcut keys).
- Fixed popup window location and size when using Windows Terminal.
- Fixed input coloring after `operate-and-get-next`; also fixes brief flicker of incorrect coloring whenever the input line is modified.

#### v1.1.24

- `auto` for `terminal.emulation` now uses native VT support on Windows 10 build 15063 and higher, unless the HKCU\Console\ForceV2 regkey is 0.
- Special quote handling now enables `"dir\"fi` to complete to `"dir\file"`.  CMD simply strips quotes during completion, and now Clink behaves similarly.
- <strong>Breaking Change:</strong> `line:getword()` and `line:getendword()` now strip quotes from the word.  This should generally automagically make existing match generators work even with embedded quotes, but there's a chance that some match generator might need to be updated.  This seems like a reasonable compromise, given the general benefit purchased by this breaking change.
- `os:globdirs()` and `os:globfile()` strip quotes from the <span class="arg">globpattern</span> in order to behave more like CMD.  Embedded quotes are nonsensical and the intended interpretation is clear, so the APIs now help out with that.
- Fixed [#66](https://github.com/chrisant996/clink/issues/66); crash when injecting into 32 bit cmd (regression introduced in v1.1.21).
- Fixed [#64](https://github.com/chrisant996/clink/issues/64); wrong cursor position when PROMPT contains BEL character.
- Fixed [#62](https://github.com/chrisant996/clink/issues/62); argmatchers should color `-x:"foo"` as a flag if `-x:` is a flag.
- Fixed [#61](https://github.com/chrisant996/clink/issues/61); argmatchers should not handle completion for text immediately following `-flag:`.  Instead it always uses file completion.  A custom generator can be used to override that behavior.
- Fixed [#60](https://github.com/chrisant996/clink/issues/60); completion fails with multiple slashes.
- Fixed completion in some circumstances.  Readline and Clink didn't always agree on where the word breaks were; now Clink always tells Readline where the word breaks are (so that completion, input colorization, and lua scripts can all work properly and consistently).
- Fixed 256 color ANSI codes.

#### v1.1.23

- Fixed [#57](https://github.com/chrisant996/clink/issues/57); slashes not normalized in some cases.
- Fixed [#45](https://github.com/chrisant996/clink/issues/45); interaction between `history.dupe_mode`=`erase_prev` and `history.shared`=`false`.
- Fixed `menu-complete-wraparound` when off and there's only 1 match.

#### v1.1.22

- Added `menu-complete-wraparound` (on by default) that controls whether completion commands wrap around when cycling past an end (affects popup windows as well).
- Fixed match completion getting stuck (regression introduced in v1.1.19).
- Fixed active mark region so it gets deactivated appropriately (it wasn't hooked up fully for Readline's callback mode, which is the mode Clink uses).
- Fixed `clink-show-help` (<kbd>Alt</kbd>-<kbd>H</kbd>) so it's able to list `C-@` bindings.
- Fixed inconsistent mark color.

#### v1.1.21

- Added `clink.oninject()` so scripts can register a callback function to run when Clink is injected into CMD.
- Added `console.linehascolor()` function that returns whether the specified line contains any of the specified colors.
- Added `console.findprevline()` and `console.findnextline()` functions that can search backwards or forwards for text and/or colors in the screen buffer.  Regular expressions may be used.
- Fixed doskey alias parsing for match generators and input line coloring (Clink had been using slightly different parsing rules than CMD does).
- Fixed the "-- More --" prompt while listing key bindings; <kbd>Esc</kbd> didn't quit, and unexpected keys weren't ignored.

#### v1.1.20

- Now you can bind Lua functions to keys via "luafunc:" macros!  Added new `rl_buffer` type that gets passed to the Lua function.
- Added a group of `console` Lua APIs intended mainly for use by Lua function key bindings (e.g. `console.scroll()`).
- Added `string.equalsi()` function that performs a case insensitive UTF8 comparison of two strings.
- Added `string.matchlen()` function that compares two UTF8 strings and returns how many characters match at the beginning, or -1 if the entire strings match. It respects the `match.ignore_case` and `match.ignore_accent` settings.
- Added `path.toparent()` function that adjust the input string by moving up one directory level.
- Added `clink.onendedit()` so scripts can register a callback function to run when editing finishes (e.g. <kbd>Enter</kbd> is pressed).  If desired, the function can even change the input text.  This is very powerful, and should be used carefully.
- Changed `os.getbatterystatus()` to return a table with the battery status details, rather than four separate return values.
- Fixed the `doskey.enhanced` setting to not expand doskey aliases when preceded by a space.  However, a doskey alias after a `&` or `|` command separator needs to be preceded by two spaces to avoid expanding it.  That's so `alias & alias` expands both, and ` alias &  alias` expands neither; while the rules are more complicated to explain, they make more sense visually.
- Fixed environment variable completion (regression introduced in v1.1.19).
- Fixed Cmder startup (regression introduced in v1.1.17).  Cmder expects to be able to replace Clink v0.4.9's clink.lua file, but there is no such thing anymore in newer versions of Clink.  To be properly backwardly compatible with Clink v0.4.9 requires loading clink.lua (if it exists) from the first script directory listed by `clink info`, and ignoring clink.lua files in all other script directories.

#### v1.1.19

- Improved responsiveness while typing:  matches are collected only on demand, instead of always while typing.  This makes it possible to always support match completion for UNC paths.
- Fixed [#50](https://github.com/chrisant996/clink/issues/50); <kbd>Alt</kbd>-<kbd>H</kbd> could warn about likely mistakes in key bindings.

#### v1.1.18

- The input text now has context sensitive coloring based on the argmatchers. It's on by default and can be turned off with `clink set clink.colorize_input false`.
- Updated the Readline library to 8.1.
- Terminal emulation now supports the audible bell character.
- Fixed [#48](https://github.com/chrisant996/clink/issues/48); `menu-complete` gets stuck.
- Fixed [#47](https://github.com/chrisant996/clink/issues/47); <kbd>Alt</kbd>-<kbd>D</kbd> erases history instead of word.
- Fixed [#46](https://github.com/chrisant996/clink/issues/46); typing `..` in subdirectory of root doesn't work.
- Fixed restoring color after pager when showing help.
- Fixed `clink set` match completions for color settings.

#### v1.1.17

- Added `os.getbatterystatus()` function that gets battery status information much faster than launching `wmic`.
- Fixed [#44](https://github.com/chrisant996/clink/issues/44); Path completion doesn't work with `cd /d`.
- Fixed loading scripts to ignore loading clink.lua, so that loading scripts behaves like Clink v0.4.9.

#### v1.1.16

- Added `match.ignore_accent` setting (enabled by default) that ignores Latin alphabet diacriticals when completing matches (e.g. `ä` matches `a`, `ı` matches `i`, `ł` matches `l`, etc).
- Fixed [#42](https://github.com/chrisant996/clink/issues/42); history lines are split on special characters.
- Fixed [#41](https://github.com/chrisant996/clink/issues/41); Enable custom doskey handling of `..` and `-`.
- Fixed Readline bug inserting dir matches; `\win_  foo` (cursor at `_`) would become `\Windows\\_  foo`.
- Fixed the `quoted-insert` command to insert just `\x1b` when <kbd>ESC</kbd> is pressed.

#### v1.1.15

- Migrating settings now immediately writes a new settings file, instead of waiting until a setting is changed.
- Added support to detect when running in Windows Terminal and use native terminal support (which enables things like Xterm 256 and 24-bit color support).
- Added terminal emulation support for Xterm 256 and 24-bit color escape codes. Clink maps the specified color to the most similar color in the active 16 color palette (using the CIELAB color space). To get full support for 24-bit color, it's necessary to use ConEmu or Windows Terminal or a similar console host, or to set `terminal.emulation` to `native` (which isn't supported on some older Windows OS versions).
- Allow doskey macros named `..` or `-`, and also now doskey macros that resolve to `..` or `-` or a directory name will work (just like if the macro text had been typed at the Clink prompt).
- Fixed compatibility problem with various scripts getting the %HOME% environment variable. Now if it isn't set, then Clink synthesizes %HOME% from %HOMEDRIVE% and %HOMEPATH% or from %USERPROFILE%.
- Fixed saving color settings to behave like other settings: only write a setting's value to the setting file if it differs from the default value.
- Fixed the `clink.print()` Lua function so it also works during loading scripts and during prompt filtering.
- Fixed the Readline input text display getting garbled if the filtered prompt includes Xterm's OSC window title code (`\x1b]0;text\x07`). Clink doesn't support that escape code, but at no longer garbles the input text if that escape code is present.

#### v1.1.14

- Migrate settings and history from an old version of Clink, if present.  This only happens if the new-version Clink settings or history files don't exist.  (Deleting an existing new-version Clink settings or history file will cause migration to happen again.)
- Added `color.prompt` setting for backward compatibility with Clink v0.4.x.

#### v1.1.13

- Fixed `clink.arg.register_parser` backward compatibility.

#### v1.1.12

- Added `clink.ondisplaymatches()` as a replacement for the deprecated `clink.match_display_filter`.  The new API is able to support popup list windows as well.
- Speculative possible fix for [#35](https://github.com/chrisant996/clink/issues/35) Crash when clink on clink.bat.
- Fixed [#33](https://github.com/chrisant996/clink/issues/33); Tab autocomplete, auto-quoting paths doesn't seem to work as in Clink 0.4.9.

#### v1.1.11

- Changed to load Lua scripts only once per session, unless forced to reload them.  This enables backward compatibility for things like [z.lua](https://github.com/skywind3000/z.lua) which has certain features that rely on Clink only loading scripts once per session.
- Added `clink.onbeginedit()` so scripts can register a callback function to run each time the edit prompt is activated.
- Added `lua.reload_scripts` setting to optionally force reloading Lua scripts each time the edit prompt is activated.
- Added `color.message` setting for the Readline message area color (e.g. the search prompt message or digit argument prompt message, etc).
- Fixed stray sticky `=` appended to completions after typing `set ` and then typing a different command.

#### v1.1.10

- Fixed [#32](https://github.com/chrisant996/clink/issues/32); hooking `ReadConsoleW` on Windows 7.

#### v1.1.9

- Added backward compatibility for `clink.match_display_filter`.  The clink-completions/git.lua script uses it a lot, and that should all be working now.
- `settings.add` adds a color setting when the type is string and the name starts with "color.".
- `settings.get` now has an extra parameter to request the user friendly color name when getting a color setting.
- Added `clink.version_encoded` variable with the Clink version number as _MMmmmpppp_ (e.g. v1.1.9 is `10010009`) to make it easy for scripts to check for feature availability.
- The `clink info` command now shows Lua script paths as well.
- Fixed backward compatibility for loading scripts from the profile directory (if `clink.path` isn't set, then load scripts from the DLL directory and the profile directory).
- Fixed some `color.input` bleed through to other things (introduced in v1.1.5).
- Fixed scroll commands (regression introduced by input line color in v1.1.5).
- Fixed horizontally sorted match display and re-enabled the performance fix from v1.1.4.
- Fixed wildcard evaluation with non-file and non-directory matches (e.g. a branch name `origin/master` accidentally didn't match `or` or `*ma` because of the `/`).
- Fixed sort order of `foo\` vs `foo.bar\` when displaying matches or using the `menu-complete` family of commands.
- Fixed potentially-missing trailing path separator when `menu-complete` completes a directory match (regression introduced by wildcard matching in v1.1.5).
- Other obscure minor fixes.

#### v1.1.8

- Fixed file match completions when an argmatcher only generates flag matches.
- Fixed automatic inferring whether Readline should use filename completion and/or display rules (regression introduced by backward compatibility in v1.1.3-alpha).
- Fixed backward compatibility for `clink.find_files()` and `clink.find_dirs()` (regression introduced by performance improvement in v1.1.7).
    - Ignore extra arguments after the first one (the performance improvement in v1.1.7 revealed that some scripts call `clink.find_files()` with extra invalid arguments; e.g. clink-completions/modules/matchers.lua).
    - Don't append a trailing path separator on directory names returned by these functions (the new `os.globfiles()` and `os.globdirs()` functions do, but the old `clink.find_files()` and `clink.find_dirs()` functions should not).
- Fixed backward compatibility for coloring matches (regression introduced by backward compatibility changes in v1.1.4).

#### v1.1.7

- Performance improvement when displaying matches:  When enumerating files and dirs, the `os.globfiles` and `os.globdirs` functions have all the info about each file.  Now they can return that info in a table.  This frees the match display function from needing to do any further file system IO.  The performance boost is noticeable.
- Rewrote the color settings:  the .fg and .bg sub-settings are gone, and the main setting now uses a more natural syntax (e.g. `clink set color.input bright yellow` or `clink set color.modmark bright cyan on blue`).
- Added "cmd" match type for shell (CMD.EXE) command completions.
- Added VT emulation for the reverse video SGR parameters.
- Fixed tab completion for <code>clink set <em>setting</em></code>, and also handle the new color setting syntax.
- Fixed confusing behavior if multiple scripts try to add settings with the same name (now the first one succeeds and the rest report errors).

#### v1.1.6

- Hooked up tilde completion in the `cd`, `md`, and `rd` command argmatchers.
- Hooked up tilde completion with the `exec.enable` setting ("~\pro" matches "C:\Users\myusername\program.exe").
- When `terminal.emulation` is `auto`, now it also detects ANSI{32|64}.DLL just like Clink 0.4.8 did.

#### v1.1.5

- The `menu-complete` family of commands now support matching `?` and `*` wildcards when the `match.wild` setting is enabled.
- Added `colour.input` and `colour.modmark` settings for coloring Readline's input line.
- Added `clink.upper()` Lua function, and both `clink.lower()` and `clink.upper()` are properly UTF8 aware now.
- Added `clink-copy-word` command that copies the word at the cursor to the clipboard.
- Added `clink.promptfilter` setting to control whether to filter the prompt with Lua scripts.
- Renamed `terminal.emulate` setting to `terminal.emulation`.
- Improved executable file extension logic to consistently use %PATHEXT% (and efficiently).
- Improved file extension logic (e.g. "file.foo bar" has no extension because of the space).
- Updated arg matcher for `clink` itself (was missing some flags).
- Changed `colour.hidden` setting to not be set by default.
- Fixed [#28](https://github.com/chrisant996/clink/issues/28); Tab completion for "~" does not work.
- Fixed [#25](https://github.com/chrisant996/clink/issues/25); Unicode surrogate pairs (and emoji) input isn't working -- Microsoft Terminal renders the text correctly, but ConEmu and the default conhost still don't (and that isn't a Clink issue).
- Fixed screen size bug in Readline on Windows.
- Fixed the backwards values in the `terminal.emulation` setting.
- Fixed `....` so it works properly again.
- Fixed case sensitive sorting of matches.
- Fixed script error when %PATHEXT% is empty.
- Fixed the `exec.cwd` Clink setting to default to true, so that the default behavior is consistent with how v0.4.x behaved.
- Fixed the `cd`, `md`, `rd`, etc argmatchers to only match one argument to be consistent with the actual command syntax.

#### v1.1.4

- Automatically detect when running inside ConEmu and disable Clink's Virtual Terminal emulation.
- Added `search-ignore-case` inputrc variable that makes the history search commands case insensitive.
- Suppress adding a space after completing a flag match that ends with `:` or `=` (e.g. `msbuild -maxCpuCount:`).
- Report any errors while loading Lua scripts.
- Report an error if a Lua script tries to add a flag string that begins with a letter.
- Fixed slow printing of possible matches.  Readline is inefficient about emitting output, so Clink supplies a custom implementation.
- Fixed some bugs in auto detection of flag prefix characters.
- Fixed backward compatibility for flags, and for args when merging two parsers by calling `clink.arg.register_parser('foo')` multiple times for the same command string.
- Fixed truncated message when the last line of a prompt exceeds 128 characters.
- Fixed abort (<kbd>Ctrl</kbd>-<kbd>G</kbd> or <kbd>Esc</kbd>) in non-incremental history search mode.
- Fixed saved values for settings added by Lua scripts; now the saved value is available to the script immediately on adding the setting, and saved values are retained even if the setting isn't always added by the script.
- Fixed (and documented) shorthand form for defining an argmatcher.
- Fixed length of colored match prefix after a path separator.
- Fixed normalizing a slash by itself (`command /` mustn't become `command \` since that can interfere with completing flags).
- Fixed the `completion-auto-query-items` inputrc variable.
- Fixed the key binding list to correctly respect `completion-display-width`.
- _No visible effect yet:  internal change that parses the input line to identify colors to use for each word (command, argument, flag, etc), but the colors aren't yet applied to the input line._

#### v1.1.3-alpha

- Fixed argmatcher lookup to be more strict, like in Clink 0.4.9 (match exact names, or name plus an extension from %PATHEXT%).
- Backward compatibility:
    - Most things should work now.
    - Dropping the new Clink on top of the vendor\clink directory in Cmder seems to work -- _but make a backup before you try this at home!_
- API changes:
    - Added `log.info()` function.
    - Added Clink version numbers in `clink.version_major`, etc.
    - Added `_argmatcher:getwordbreakinfo()` callback; removed `_argmatcher:setprefixincluded()` (it was a mess, and it was new to v1.x, so there's no compatibility concern with removing it).
    - Deprecated `_argmatcher:setflagprefix()`; now it happens automagically when using `_argmatcher:addflags()`.
    - Introduced several deprecated functions to support backward compatibility.
- Improvements to Lua debugger:
    - Added `lua.traceback_on_error`, `lua.break_on_error`, and `lua.break_on_traceback` settings to make debugging script errors easier.
    - Made `pause()` consistent about pausing in the caller (rather than sometimes inside the pause command itself).
    - The debugger automatically shows the stack trace when entering debug mode, and on every pause.
    - Show 3 lines of source context by default.
    - The help list is sorted now.
    - Fixed the `set` command in the debugger to behave as documented.

#### v1.1.2-alpha

- Documentation is mostly updated; just the argmatcher Lua API and Clink command line options are left to be documented.
- Added `history.max_lines` setting that controls how many lines of command history to save (1 to 50000, default is 2500).
- Added `readline.hide_stderr` setting that can suppress stderr output from the Readline library.
- For backward compatibility with 0.4.8, `clink_inputrc` files are loaded as well.
- Lua script API changes:
    - `addmatch()` in Lua scripts takes an optional match type argument.
    - Removed `displayable`, `aux`, and `suffix` fields in matches.
    - Revert the change to disallow mixing file/directory/symlink with other match types (it broke the tests and certain completion scenarios).
- Fixed issues:
    - [#18](https://github.com/chrisant996/clink/issues/18) alt+digit then alt+ctrl+y isn't working.
    - [#17](https://github.com/chrisant996/clink/issues/17) arrow keys don't exit `reverse-search-history` like in bash.
    - [#16](https://github.com/chrisant996/clink/issues/16) problems with $T in doskey macros.
    - [#13](https://github.com/chrisant996/clink/issues/13) `clink history delete <n>` returns a CRT error.
- Other fixes:
    - There should be no more problems running on Windows Insider builds because Clink now uses [Detours](https://github.com/microsoft/detours) for hooking APIs.
    - Fixed crash in `insert-completions` due to heap failure (introduced by the performance changes for displaying matches).
    - Fixed `clink` and `history` built-in aliases (solve glitchy path problem).
    - Fixed scrolling to top of screen buffer.
    - Fixed env var and `set` completions.
    - Fixed `tilde-expand` for quoted text.
    - Fixed <kbd>Esc</kbd> in Readline's digit argument input mode (it doesn't try to cancel the mode, because that's not how Readline is documented to work).
    - Fixed exit code from some `clink` command line options.
- Set locale to UTF8 much earlier to avoid quirky behavior early in script processing.

#### v1.1.1-alpha

- Exclusively use Readline's completion implementation.  This (with fixes and enhancements in Readline itself) makes the completion experience much nicer and more sophisticated, and removes a lot of code that was added in v1.0.0a0.
- Exclusively use Readline's key binding implementation.  This makes it possible to have a single consistent way to set key bindings (inputrc) and for `clink-show-help` to list all key bindings, and removes a lot of code that was added in v1.0.0a0.
- Converted all of Clink's internal key behaviors to be implemented as commands that can be bound in the inputrc file.
- Rewrote and refactored the pagination routine to be used in multiple places.
- Fixed prompt filtering to correctly use the specified priority order.
- Readline library:
    - Updated the Readline library from v6.2 to v8.0.  This picked up lots of bug fixes and new capabilities (for example colored completions).
    - Changed Readline to support backslash as a path separator.
    - The pager prompt in Readline is optionally colored, controlled by the `colour.interact` Clink setting.
    - Added `completion-auto-query-items` config variable (on by default) which asks whether to list possible matches when the number of lines listed will fill one screen page.
    - Added `history-point-at-end-of-anchored-search` config variable in inputrc to make the cursor point behave like 4Dos/4NT/TakeCommand when searching forward and backward through command history.
    - Fixed prev history at top of history.
    - Fixed to get the current values of environment variables when needed, rather than always getting the value from whenever Clink was started.
    - Fixed coloring directory completions.
    - Fixed `menu-complete` for `\dir` and `.` and `..`.
    - Fixed slow performance when displaying matches.  Readline was calling stat() at least once per match (!!).  A new match type field enables faster performance, coloring readonly and hidden file matches, applying filename completion rules only to filenames (vs branch names or other text strings), correct match de-duplication, and more.  The Lua match APIs can supply the new match type.
    - Fixed inserting a completion to happen as a single undo group.
    - Fixed tilde to map to `%USERPROFILE%` instead of `%APPDATA%` on Windows.
- Typing a directory by itself uses `cd /d` to change to the directory:
    - Typing a directory with a trailing path separator changes to the directory.
    - Typing `..\` changes to the parent directory.
    - Typing `...` or `....` etc moves up an extra parent directory level for each extra dot (2 dots move up one parent, 3 dots moves up two parents, etc).  A trailing path separator is optional when there are more than 2 dots.
    - Typing `-` or `cd -` or `chdir -` changes to the previous directory.
- Commands that are new, enhanced, or fixed:
    - Added `add-history` and `remove-history` commands (similar to 4Dos/4NT/TakeCommand).
    - Got the `menu-complete`, `menu-complete-backward`, and `old-menu-complete` commands working (they never worked properly before in Clink).
        - Also added a corresponding `old-menu-complete-backward` command for reverse order.
        - All of the `*-menu-complete-*` commands support wildcards (`*` and `?`).
    - Added `clink-show-help` command (<kbd>Alt</kbd>-<kbd>H</kbd>).  The help now lists _**all**_ key bindings, and it shows user-friendly key names (like `A-Up` or `C-x,C-r` or `C-S-PgUp` or `A-C-S-F3`).
    - Added `clink-popup-completions` command that shows a popup window listing possible completions.  <kbd>Enter</kbd> inserts the highlighted completion.
    - Added `clink-popup-directories` command that shows a popup window listing recent directories.  <kbd>Enter</kbd> changes to the highlighted directory, or <kbd>Shift</kbd>-<kbd>Enter</kbd> inserts the highlighted directory in the editing line (or <kbd>Ctrl</kbd>-<kbd>Enter</kbd>).
    - Added `clink-popup-history` command that shows a popup window listing command history.  <kbd>Enter</kbd> executes the highlighted command, or <kbd>Shift</kbd>-<kbd>Enter</kbd> jumps to the highlighted command in the history (or <kbd>Ctrl</kbd>-<kbd>Enter</kbd>).
    - Added `clink-scroll-lineup`, `clink-scroll-linedown`, `clink-scroll-page-up`, `clink-scroll-page-down`, `clink-scroll-top`, and `clink-scroll-bottom` commands that do what it looks like they'd do and are bound to the keys it looks like they'd be.
    - Added `clink-expand-doskey` command (<kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>f</kbd>) that expands the current line according to the current doskey aliases.
    - Added `clink-expand-env-var` command (<kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>e</kbd>) that expands the environment variable at the cursor point.
    - Added `clink-exit` command (<kbd>Alt</kbd>-<kbd>F4</kbd>) that exits CMD.
- Fixed keyboard input issues:
    - <kbd>Esc</kbd> is a bindable key now (`\e[27;27~`).
    - Added more bindable key combinations (run `clink echo` then press keys to see the key sequence to use in the inputrc file).
    - <kbd>Ctrl</kbd>-<kbd>@</kbd> (NUL) didn't work.
    - <kbd>Ins</kbd> toggles insert/overwrite mode.
    - Unbound keys are ignored now, instead of inserting gibberish characters (part of the terminal internal key sequence).
    - Fixed input handling so the `quoted-insert` command can work properly.
    - Fixed <kbd>Esc</kbd> while searching.
    - Fixed vi mode (was working in v0.4.9, but not in v1.0.x).
- Fixed command history issues:
    - The `dont_add_to_history_cmds` Clink setting is a space-delimited list of commands to not add to history.
    - Fixed bleeding between history banks.
    - Fixed uninitialized variable that made history updates intermittently do nothing or corrupt the other history bank.
    - Fixed output from `clink history` to convert to UTF16 when writing to the console (but write UTF8 when output is redirected).
- Fixed terminal output issues:
    - Added `terminal.emulate` Clink setting that controls whether Clink does VT emulation or passes all ANSI escape codes directly to the console host.  For example, this lets the prompt and completion coloring take advantage of more sophisticated ANSI escape codes such as XTerm 256 color and 16 bit color support.
    - Added back support for the `prefer-visible-bell` config variable.
    - Fixed underline support.
    - Fixed handling for UTF8 output from Readline.
    - Fixed invisible cursor point in Lua debugger.
- Completions:
    - Added `match.sort_dirs` Clink setting that specifies where to sort directories in the list of possible completions:  before files, mixed in with files, or after files.
    - Don't attempt completing incomplete UNC paths:  at least the `\\server\share\` path components are required (for anything shorter the OS APIs are guaranteed to fail, but will fail slowly).
    - Fixed sorting to use Unicode aware locale based sorting (like Windows does) instead of dumb UTF8 byte comparisons.
    - Fixed arbitrary limit on completions (had been limited to 64KB worth of completions).
    - Fixed quoting spaces in completions.
    - Fixed to use the same list as CMD for characters that require quoting.
    - Fixed normalizing UNC paths.
    - Fixed volume relative completions (e.g. `x:foo`).
    - Disallow mixing file/directory/symlink with other match types.  This was to avoid a confusing/malfunctioning case in match display and prefix highlighting.
- Fixed UTF8 encoding in various Lua functions.
- Fixed printing stderr output from Readline, Lua, and Clink.
- Fixed crashes and other failures when starting Clink in 32 bit CMD.
- Fixed some memory leaks that accumulated with each new line of input.
- Fixed prompt filtering API to be backward compatible with v0.4.9 scripts.
- Fixed Lua errors from `clink set` (it neglected to fully initialize Clink's Lua integration before loading Lua scripts).
- Fixed UTF8 conversion bug that could truncate a string without fully converting it.
- Fixed serious rampant memory corruption bug in v1.0.x (not present in v0.4.9), which had been causing intermittent malfunctions and data corruption and crashes.
- Fixed multi-line doskey macros to show the prompt in between lines, like CMD does.
- Removed the 4096 byte limit on input.
- Renamed the Clink DLL back to what it was in v0.4.x, to fix compile time problems.
- Other fixed issues:
    - [mridgers #544](https://github.com/mridgers/clink/issues/544) Clink v1.0.0.a1 doesn't support cyrillic characters keyboard input on Windows 10 with console V2.
    - [mridgers #543](https://github.com/mridgers/clink/issues/543) Not compatible with Windows Insider Build 20150.
    - [mridgers #537](https://github.com/mridgers/clink/issues/537) Clink breaks the CMDS tool.
    - [mridgers #520](https://github.com/mridgers/clink/issues/520) Clink 1.0.0.a1 - `clink set history_io 1` Error.
    - [mridgers #519](https://github.com/mridgers/clink/issues/519) Clink v1.0.0.a1 - `-s|--scripts [path]` command line arg removed?
    - [mridgers #516](https://github.com/mridgers/clink/issues/516) Doskey $T not handled properly.
    - [mridgers #512](https://github.com/mridgers/clink/issues/512) Command history missing in .history.
    - [mridgers #503](https://github.com/mridgers/clink/issues/503) Keyboard shortcut for scrolling.
    - [mridgers #501](https://github.com/mridgers/clink/issues/501) <kbd>Ctrl</kbd>-<kbd>Backspace</kbd> works now.
    - [mridgers #487](https://github.com/mridgers/clink/issues/487) Clink breaks ConEmu-specific Escape codes.
    - [mridgers #480](https://github.com/mridgers/clink/issues/480) History never saved.
    - [mridgers #465](https://github.com/mridgers/clink/issues/465) Using LuaJIT (FFI).
    - [mridgers #456](https://github.com/mridgers/clink/issues/456) Clear-screen not working properly when PROMPT is two lines long.
    - [mridgers #453](https://github.com/mridgers/clink/issues/453) Wrong cursor position when a line contains non-printable characters.
    - [mridgers #442](https://github.com/mridgers/clink/issues/442) Unable to paste more than 1024 characters using <kbd>Ctrl</kbd>-<kbd>V</kbd>.
    - [mridgers #422](https://github.com/mridgers/clink/issues/422) Problem with filename modifiers.
    - [mridgers #420](https://github.com/mridgers/clink/issues/420) Use NtSuspendProcess instead of CreateToolhelp32Snapshot to freeze the threads.
    - [mridgers #372](https://github.com/mridgers/clink/issues/372) Provide a way to select a previous directory.
    - [mridgers #365](https://github.com/mridgers/clink/issues/365) history-search behavior.
    - [mridgers #342](https://github.com/mridgers/clink/issues/342) Clink_inputrc not being processed if it the clink_inputrc is a link (created via mklink).
- Fixed many other bugs.

### Releases from [mridgers/clink](https://github.com/mridgers/clink) original repo

#### v1.0.0a1 _(alpha test release)_

- Improve terminal integration with the Readline library.
- Internal improvements to the built-in ecma48 terminal emulator.
- Fixed use after free in Doskey emulation.
- Fixed dash-dash flag completion.
- Search ancestors for a compatible target process (for when cmd.exe starts another process that subsequently starts clink; especially useful during development).
- Use clink/terminal's wcwidth() implementation.
- screen_buffer::set_cursor() should be relative to the visible area.
- Try to adjust the cursor position better when resizing the terminal.
- Some internal Lua functions needed the unquoted clink exe path.
- The origin path now affects the hash in the dll cache, to guard against directory moves.
- More code reorganization.

#### v1.0.0a0 _(alpha test release)_

- Extensive code reorganization, refactoring, and rewriting -- multiple times -- almost everything was touched.
- OS integration:
    - Fixed Doskey macros on Win8, and on Win10.
    - Fixed `clink_x??.exe` startup stall on Windows 10.
    - Removed XP support. It doesn't load DLLs like Clink uses them.
    - Removed Powershell support.
- Readline integration:
    - Search for multiple places for [.|_]inputrc (fixes [mridgers #258](https://github.com/mridgers/clink/issues/258)).
    - Disabled Readline's completion code, and only use the clink alternative code.
    - Removed redundant slash translation and shims to make it happen.
    - Removed control of Readline's suffix appending and disabled it.
- `clink` commands and flags:
    - Changed `--cfgdir` to `--profile`, it's no longer required, and added help about it.
    - Added a `--version` option to print Clink's version.
    - Added `clink info` to print information about Clink.
    - Added `clink echo` command to echo input key sequences to stdout.
    - Added `clink history` command (fixes [mridgers #172](https://github.com/mridgers/clink/issues/172)).
    - Added `history` as an alias for `clink history`.
    - Added internal `--list` flag to `clink set` for match generation.
    - Removed `--scripts` argument (fixes [mridgers #206](https://github.com/mridgers/clink/issues/206)).
    - Updated `clink autorun` command's help text.
- Lua scripts:
    - Prefer `userprofile` over other standard environment variables for where to look for lua scripts.
    - New API for argument style completion scripts.
    - Refactored prompt filtering, and introduced new prompt filtering API.
    - Refactored generating matches, and introduced new match generator API.
    - Removed built in completions scripts for git, go, hg, and p4. There's better ones.
    - Renamed many of clink's Lua functions.
    - Moved functions from `clink` to `os` in Lua.
    - Removed `clink.is_match()` in Lua; don't presume anything on anyone's behalf about matches.
    - Added some current dir functions in Lua.
    - Added some env/dir functions in Lua.
    - Exposed path manipulation functions to Lua.
    - Embed the core Lua scripts instead of loading them from files.
- Terminal IO:
    - Added a module for scrolling the screen.
    - Rewrote the terminal emulation module, and all Readline IO goes through it.
    - Use VT220-style control codes for special keys.
    - If <kbd>Alt</kbd> is pressed send ESC in the input stream rather than setting meta bit.
    - Replaced wcwidth() with a more complete and correct version.
- Settings:
    - Added `clink_path` setting for where to look for lua scripts.
    - Added `match.ignore_case` setting.
    - Added `files.unc_paths` setting for optional matching from UNC paths.
    - Added a setting to skip adding lines that start with `history`.
    - Removed `esc_clears_line` setting.
    - Pasting CRLFs doesn't really make sense.
    - Don't write out settings that are set to default.
- Make sure <kbd>Ctrl</kbd>-<kbd>C</kbd> doesn't modify history.
- Make a cached copy of Clink's DLL when injecting so as to not lock the master.
- Guard against Readline's writes to stderr.
- Remove `clink_inputrc_base` file and embed its content (fixes [mridgers #257](https://github.com/mridgers/clink/issues/257)).
- Include more metadata in the Clink's executables.

#### v0.4.9

- Fixed broken Doskey on Win10 (#438, #451)

#### v0.4.8

- Environment variable `clink_profile` overrides Clink's profile path (#390).
- Load a clink_inputrc file from Clink's profile directory (fixes #406).
- Bug fixes;
    - Redraw issues when prompts end in OSC ANSI codes (#387, #384).
    - Fixed `clink autorun --help` crash.

#### v0.4.7

- Bug fixes;
    - Sometimes autorun tries to run clink.exe (#374).
    - Autorun would cause cmd.exe to return an error if it wasn't interactive (#373).

#### v0.4.6

- HOME is only set if it is currently unset.
- Readline can be initialised with .inputrc and _inputrc files too (#258).
- Bug fixes;
    - Executable completion;
        - Paths from PATH were checked twice.
        - Incorrect results were returned for words ending in `.` or `-`.
        - Directories . and .. were incorrectly displayed.
    - Fixed a crash if .bat script's stdout is redirected (#366).
    - Occasional crash when injecting Clink (#351).
    - Display errors;
        - When editing near the window's right-hand edge (#347).
        - Double display of multi-line prompts when resizing the terminal (#352).
        - Very rare wrap artefacts when making the terminal window larger.
    - Doskey emulation (#344).
    - Improved `clink autorun` help (#348).
    - Fixed launching Clink when clink.bat is renamed (#357).

#### v0.4.5

- Improved `clink autorun`. It now defaults to the Current User registry hive.
- `clink set` gives more details for enumeration-type settings.
- Tab completion for p4vc.
- New settings `history_expand_mode` to control history expansion in quotes (#317).
- Bug fixes;
    - Use full width of the terminal (#337).
    - Fixed MinGW compile error (#335).
    - Autorun now defaults to the current user's hive (#332).
    - Creating clink.html no longer needs Pandoc, plus it looks a bit better (#331).
    - Added settings to control history expansion (#326).
    - Correct fallback when `use_altgr_substitute` is off (#325).
    - Load history prior to saving it on shutdown (#318).
    - Added Shift-Tab documentation and menu completion example (#190).
    - Added shim for backwards menu completion (#190).
    - Input handling now outputs <code>\e`Z</code> for <kbd>Shift</kbd>-<kbd>Tab</kbd> (#190).
    - Updated Readme with current Premake info (#310).
    - Guard against there being no buffer to read from (#304).
    - Fixed artefacts when resizing conhost's buffer (#139).
    - Clear remaining characters if scroll window was too small (#301)
    - Escape % characters when expanding aliases (#280).
    - Fixed leaking exception filters.
    - Clearing the screen doesn't leave artefacts behind.

#### v0.4.4

- Completing .. behaves more like Bash (#277).
- Escape from yes/no question when <kbd>Ctrl</kbd>-<kbd>C</kbd> is pressed.
- Valid XP executables (#278, #289).
- Fixed n-th argument yank not working as expected (#254).
- Fixed prompt colours sometimes not working (#279, #286).
- Fixed `!0` causing Clink to crash.
- Save/restore cursor position in case Readline moves it.

#### v0.4.3

- Localised Y/N when auto-answering "terminate?" prompt.
- `$*` would early out if there was no arguments.
- Disable ANSI code support if third party provides it.
- Installer can now set %CLINK_DIR% to install location.
- Improved output from `clink set`.
- Support for Windows 10 Technical Preview.
- <kbd>Ctrl</kbd>-<kbd>L</kbd> now scrolls last line to the top of the window rather than clearing.
- New option to control how newline characters are pasted to the line.
- New options to control history;
    - `history_file_lines` - maximum lines saved to disk.
    - `history_ignore_space` - ignore lines prefixed with whitespace.
    - `history_dupe_mode` - how duplicate entries are handled.
    - `history_io` - load/save history from disk every line.
- Fixed nonfunctional numpad keys.
- Fixed missing WINCH signals if other processes resize the buffer.
- Support <kbd>Alt</kbd> codes sent from Conhost.

#### v0.4.2

- Prompt colouring no longer requires third party ANSI code utility.
- Override settings with environment variables prefixed with 'clink'.
- Ctrl-PgUp goes up a directory.
- Updated Go completions (by matrixik).
- Arguments to clink.arg.new_parser() now initialise parser's flags/args (from vladimir-kotikov).
- New clink.arg.add_flags() and clink.arg.add_arguments() functions.
- Removed footer and <kbd>Alt</kbd>-<kbd>H</kbd> tip for more succinct stdout output.
- Bug fixes;
    - Windows XP works again.
    - Fixed race condition in lua_execute().

#### v0.4.1

- Bug fixes;
    - Various Unicode fixes causing corrupt environment variables.
    - Fixed thread resume/suspend causing rare system-wide deadlock.
    - Fixed incorrect translation of suffixed slash when completing flags.
- Add `--nolog` argument to disable file logging. Fix #187 Fix #154
- Added missing escape sequences from doskey emulation.
- Reinstated unix-kill-line key binding.
- Mapped <kbd>PgUp</kbd>/<kbd>Down</kbd> to search history using line typed so far.
- Added documentation covering escape codes for special keys.
- Added support for Windows' <kbd>AltGr</kbd> substitute <kbd>Ctrl</kbd>-<kbd>Alt</kbd>.
- Support for Readline's 'menu' style completion (see docs).

#### v0.4

- New features;
    - Better `clink.arg` API. Easier, more intuitive, and more powerful.
    - Whitespace prefix skips exec matching.
    - Added a `set` verb to easily change settings from the command line.
    - Basic support for a shells other than cmd.exe.
    - Completion for Go (contributed by Dobroslaw Zybort).
    - Setting `exec_match_style` to -1 disables it entirely.
    - Make history persistence optional.
    - Alias/doskey completion.
    - Very basic support for Powershell.
    - View cmd.exe's autorun entry without needing admin rights.
- New key bindings;
    - <kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>C</kbd> : Copy command line to the clipboard.
    - <kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>E</kbd> : Expand environment variable under cursor.
    - <kbd>Ctrl</kbd>-<kbd>Alt</kbd>-<kbd>U</kbd> : "up directory" (formerly <kbd>Shift</kbd>-<kbd>Up</kbd>).
    - <kbd>Ctrl</kbd>-<kbd>U</kbd> : Adds `..\` to the command line.
    - <kbd>Alt</kbd>-<kbd>H</kbd> : Shows active keymap's key bindings.
- New Lua functions;
    - clink.execute().
    - clink.get_host_process().
    - clink.match_files().
    - clink.match_words().
    - clink.get_console_aliases().
- Lots of bug fixes, including;
    - Better command extraction.
    - Fixed cmd.exe command paging and <kbd>Ctrl</kbd>-<kbd>C</kbd>/<kbd>Ctrl</kbd>-<kbd>Break</kbd> handling.
    - Multiple locale fixes.
    - Use localised text for "Terminate batch job?" prompt.

#### v0.3

- Automatic answering of cmd.exe's "Terminate batch script?" prompt.
- Coloured prompts (requires ANSICON or ConEmu).
- Added Shift-Up keyboard shortcut to automatically execute `cd ..`
- Mapped <kbd>Ctrl</kbd>-<kbd>Z</kbd> to undo, Microsoft style.
- Improved integration of Readline;
    - New input handling code (<kbd>Ctrl</kbd>-<kbd>Alt</kbd> combos now work).
    - An implementation of the Termcap library.
    - Fully functional Vi-mode support.
    - Support for resizable consoles.
    - Line wrapping now works correctly (issue 50).
- Adjustable executable match style (issue 65).
- Improved environment variable completion.
- Added settings file to customise Clink.
- New Lua features and functions;
    - Matches can now be filtered in Lua before they are display.
    - clink.quote_split().
    - clink.arg.node_merge().
    - clink.get_screen_info() (issue 71).
    - clink.split() (for splitting strings).
    - clink.chdir().
    - clink.get_cwd().
    - Functions to query Clink's settings.
- New command line options;
    - <code>--profile <span class="arg">dir</span></code> to override default profile directory.
    - `--nohostcheck` disables verification that host is cmd.exe.
    - `--pid` specifies the process to inject into.
- Update Mercurial completion (issue 73).
- Start menu shortcut starts in USERPROFILE, like cmd.exe
- Zip distribution is now portable.

#### v0.2.1

- The .history file now merges multiple sessions together.
- Fixed missing y/n, pause, and other prompts.
- Fixed segfault in loader executable.
- Better ConEmu compatibility.

#### v0.2

- Basic argument completion for `git`, `hg`, `svn`, and `p4`.
- Traditional Bash clear screen (<kbd>Ctrl</kbd>-<kbd>L</kbd>) and exit shortcuts (<kbd>Ctrl</kbd>-<kbd>D</kbd>).
- Scrollable command window using <kbd>PgUp</kbd>/<kbd>PgDown</kbd> keys.
- Doskey support.
- Automatic quoting of file names with spaces.
- Scriptable custom prompts.
- New argument framework to ease writing context-sensitive match generators.
- History and log file is now saved per-user rather than globally.
- Improved Clink's command line interface (`clink --help`).
- More reliable handling of cmd.exe's autorun entry.
- General improvements to executable and directory-command completion.
- Symbolic link support.
- Documentation.
- Windows 8 support.
- Improved hooking so Clink can be shared with other thirdparty utilities that
  also hook cmd.exe (ConEmu, ANSICon, etc.).

#### v0.1.1

- Fixed <kbd>AltGr</kbd>-<kbd>&lt;key&gt;</kbd> on international keyboards.
- Fixed broken completion when directories have a `-` in their name (Mark Hammond)
- The check for single match scenarios now correctly handles case-insensitivity.

#### v0.1

- Initial release.
