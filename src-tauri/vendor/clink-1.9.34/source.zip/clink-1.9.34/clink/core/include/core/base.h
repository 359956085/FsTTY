// Copyright (c) 2015 Martin Ridgers
// License: http://opensource.org/licenses/MIT

#pragma once

#if defined(_MSC_VER)
#define sizeof_array(x)     _countof(x)
#else
#define sizeof_array(x)     (sizeof(x) / sizeof(x[0]))
#endif

#define AS_STR(x)           AS_STR_IMPL(x)
#define AS_STR_IMPL(x)      #x

#if defined(_WIN32)
#   define PLATFORM_WINDOWS
#else
#   error Unsupported platform.
#endif

#if defined(_MSC_VER) && _MSC_VER < 1900
#   define threadlocal      __declspec(thread)
#else
#   define threadlocal      thread_local
#endif

#if defined(_MSC_VER) && _MSC_VER < 1900
#   define align_to(x)       __declspec(align(x))
#else
#   define align_to(x)      alignas(x)
#endif

#if defined(_M_AMD64) || defined(__x86_64__)
#   define ARCHITECTURE         64
#   define ARCHITECTURE_NAME    x64
#   define ARCHITECTURE_x64     1
#elif defined(_M_IX86) || defined(__i386)
#   define ARCHITECTURE         86
#   define ARCHITECTURE_NAME    x86
#   define ARCHITECTURE_x86     1
#elif defined(_M_ARM64) || defined(__aarch64__)
#   define ARCHITECTURE         64
#   define ARCHITECTURE_NAME    arm64
#   define ARCHITECTURE_arm64   1
#else
#   error Unknown architecture
#endif

#define ARCHITECTURE_IS(x)    ARCHITECTURE_##x

#undef min
template <class A> A min(A a, A b) { return (a < b) ? a : b; }

#undef max
template <class A> A max(A a, A b) { return (a > b) ? a : b; }

#undef clamp
template <class A> A clamp(A v, A m, A M) { return min(max(v, m), M); }

//------------------------------------------------------------------------------
#include <cstdint>
using int8  = int8_t;  using uint8  = uint8_t;
using int16 = int16_t; using uint16 = uint16_t;
using int32 = int32_t; using uint32 = uint32_t;
using int64 = int64_t; using uint64 = uint64_t;

//------------------------------------------------------------------------------
#if defined(PLATFORM_WINDOWS)
#   define PATH_SEP "\\"
#   define PATH_SEP_CHAR '\\'
#else
#   define PATH_SEP "/"
#   define PATH_SEP_CHAR '/'
#endif

//------------------------------------------------------------------------------
#define FILE_LINE __FILE__ "(" AS_STR(__LINE__) "): "
#if !defined(_MSC_VER) || defined(HIDE_TODO)
#define TODO(s)
#define WARNING(s)
#else
#define TODO(s) __pragma(message (FILE_LINE /*"warning: "*/ "TODO: " s))
#define WARNING(s) __pragma(message (FILE_LINE /*"warning: "*/ "WARN: " s))
#endif
//#define PRAGMA_ERROR(s) __pragma(message (FILE_LINE "error: " s))

//------------------------------------------------------------------------------
extern const char* get_bindable_esc();

//------------------------------------------------------------------------------
#if defined(DEBUG)
int32 dbg_get_env_int(const char* name, int32 default_value=0);
void dbg_printf_row(int32 row, const char* fmt, ...);
void dbg_printf(const char* fmt, ...);
#endif

//------------------------------------------------------------------------------
#undef assertimplies
#ifdef NDEBUG
#define assertimplies(a, b) ((void)0)
#else
#define makeassertimpliestext3(x, y, z) x y z
#define makeassertimpliestext(a, b) makeassertimpliestext3(_CRT_WIDE(#a), _CRT_WIDE(" IMPLIES "), _CRT_WIDE(#b))
#define assertimplies(a, b) ((void)(    \
        (!(a) || !!(b)) ||              \
        (_wassert(makeassertimpliestext(a, b), _CRT_WIDE(__FILE__), (unsigned)(__LINE__)), 0)))
#endif


//------------------------------------------------------------------------------
struct no_copy
{
            no_copy() = default;
            ~no_copy() = default;

private:
            no_copy(const no_copy&) = delete;
            no_copy(no_copy&&) = delete;
    no_copy& operator = (const no_copy&) = delete;
    no_copy& operator = (no_copy&&) = delete;
};

//------------------------------------------------------------------------------
template <class T> class rollback : public no_copy
{
public:
            rollback(T& var) : m_var(var), m_rollback(var) {}
            rollback(T& var, const T value) : rollback(var) { m_var = value; }
            ~rollback() { if (m_var != m_rollback) m_var = m_rollback; }

    void    reset() { if (m_var != m_rollback) m_var = m_rollback; }

private:
    T&      m_var;
    const T m_rollback;
};

//------------------------------------------------------------------------------
// Remove top-level const qualifier.
template <class T> struct remove_const { using type = T; };
template <class T> struct remove_const<const T> { using type = T; };
template <class T> using remove_const_t = typename remove_const<T>::type;

//------------------------------------------------------------------------------
template <class T> struct autoptr
{
    autoptr(T* p) : m_p(p) {}
    autoptr(const autoptr<T>& other) = delete;
    autoptr(autoptr<T>&& other) { m_p = other.m_p; other.m_p = nullptr; }
    ~autoptr() { free(const_cast<remove_const_t<T>*>(m_p)); }
    autoptr<T>& operator=(const autoptr<T>& other) = delete;
    autoptr<T>& operator=(autoptr<T>&& other) { m_p = other.m_p; other.m_p = nullptr; }
    T* get() const { return m_p; }
    T** operator&() const { return const_cast<T**>(&m_p); }
private:
    T* m_p;
};

//------------------------------------------------------------------------------
template <class T> inline void suppress_unused_var(T var) {}

//------------------------------------------------------------------------------
void install_crt_invalid_parameter_handler();
