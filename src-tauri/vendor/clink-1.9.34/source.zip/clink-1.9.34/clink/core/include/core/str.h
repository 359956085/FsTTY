// Copyright (c) 2015 Martin Ridgers
// License: http://opensource.org/licenses/MIT

#pragma once

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <utility>

#include <assert.h>

class str_base;
class wstr_base;

//------------------------------------------------------------------------------
inline bool     is_null_or_empty(const char* s)                        { return !s || !*s; }
inline bool     is_null_or_empty(const wchar_t* s)                     { return !s || !*s; }
inline uint32   str_len(const char* s)                                 { return uint32(strlen(s)); }
inline uint32   str_len(const wchar_t* s)                              { return uint32(wcslen(s)); }
inline void     str_ncat(char* d, const char* s, size_t n)             { strncat(d, s, n); }
inline void     str_ncat(wchar_t* d, const wchar_t* s, size_t n)       { wcsncat(d, s, n); }
inline int32    str_cmp(const char* l, const char* r)                  { return strcmp(r, l); }
inline int32    str_cmp(const wchar_t* l, const wchar_t* r)            { return wcscmp(r, l); }
inline int32    str_icmp(const char* l, const char* r)                 { return stricmp(r, l); }
inline int32    str_icmp(const wchar_t* l, const wchar_t* r)           { return wcsicmp(r, l); }
inline int32    vsnprint(char* d, int32 n, const char* f, va_list a)        { return vsnprintf(d, n, f, a); }
inline int32    vsnprint(wchar_t* d, int32 n, const wchar_t* f, va_list a)  { return _vsnwprintf(d, n, f, a); }
inline const char*    str_chr(const char* s, int32 c)                  { return (c & ~0xff) ? nullptr : strchr(s, c); }
inline const wchar_t* str_chr(const wchar_t* s, int32 c)               { return wcschr(s, wchar_t(c)); }
inline const char*    str_rchr(const char* s, int32 c)                 { return (c & ~0xff) ? nullptr : strrchr(s, c); }
inline const wchar_t* str_rchr(const wchar_t* s, int32 c)              { return wcsrchr(s, wchar_t(c)); }
inline const char*    str_or_empty(const char* s)                      { return s ? s : ""; }
inline const wchar_t* str_or_empty(const wchar_t* s)                   { return s ? s : L""; }

uint32 char_count(const char*);
uint32 char_count(const wchar_t*);

void make_spaces(uint32 num, str_base& out);
void concat_spaces(str_base& str, uint32 num);

//------------------------------------------------------------------------------
template <typename TYPE>
class str_impl
{
public:
    typedef TYPE        char_t;
    typedef uint16      size_type;

                        str_impl(TYPE* data, uint32 size);
                        str_impl(const str_impl&) = delete;
                        ~str_impl();
    void                attach(TYPE* data, uint32 size);
    bool                reserve(uint32 size, bool exact = false);
    TYPE*               data();
    const TYPE*         c_str() const;
    uint32              size() const;
    bool                is_growable() const;
    uint32              length() const;
    uint32              char_count() const;
    void                clear();
    bool                empty() const;
    void                truncate(uint32 length);
    void                trim();
    int32               first_of(int32 c) const;
    int32               last_of(int32 c) const;
    bool                equals(const TYPE* rhs) const;
    bool                iequals(const TYPE* rhs) const;
    bool                copy(const TYPE* src);
    bool                concat(const TYPE* src, int32 n=-1);
    bool                concat_no_truncate(const TYPE* src, int32 n);
    bool                format(const TYPE* format, ...);
    bool                vformat(const TYPE* format, va_list args);
    bool                format_append(const TYPE* format, ...);
    bool                vformat_append(const TYPE* format, va_list args);
    TYPE                operator [] (uint32 i) const;
    str_impl&           operator << (const TYPE* rhs);
    template <int32 I>
    str_impl&           operator << (const TYPE (&rhs)[I]);
    str_impl&           operator << (const str_impl& rhs);
    void                operator = (const str_impl&) = delete;

protected:
                        str_impl(str_impl&&) noexcept;
    void                set_growable(bool state=true);
    str_impl&           operator = (str_impl&&) noexcept;
    bool                owns_ptr() const;
    void                reset_not_owned(TYPE* data, uint32 size);
    void                free_data();

private:
    TYPE*               m_data;
    size_type           m_size;
    mutable size_type   m_length;
    bool                m_growable;
    bool                m_owns_ptr;
protected:
    TYPE                m_reservation;  // Used by str_moveable.
#ifdef DEBUG
    TYPE                m_guard;        // Used by str_moveable.
#endif
};

//------------------------------------------------------------------------------
template <typename TYPE>
str_impl<TYPE>::str_impl(TYPE* data, uint32 size)
: m_data(data)
, m_size(size)
, m_length(0)
, m_growable(0)
, m_owns_ptr(0)
{
}

//------------------------------------------------------------------------------
template <typename TYPE>
str_impl<TYPE>::~str_impl()
{
    free_data();
}

//------------------------------------------------------------------------------
template <typename TYPE>
str_impl<TYPE>::str_impl(str_impl&& s) noexcept
{
    *this = std::move(s);
}

//------------------------------------------------------------------------------
template <typename TYPE>
void str_impl<TYPE>::attach(TYPE* data, uint32 size)
{
    if (is_growable())
    {
        free_data();
        m_data = data;
        m_size = size;
        m_owns_ptr = 1;
        m_length = 0;
    }
    else
    {
        clear();
        concat(data, size);
        free(data);
    }
}

//------------------------------------------------------------------------------
template <typename TYPE>
void str_impl<TYPE>::set_growable(bool state)
{
    m_growable = state ? 1 : 0;
}

//------------------------------------------------------------------------------
template <typename TYPE>
bool str_impl<TYPE>::reserve(uint32 new_size, bool exact)
{
    if (!exact)
        new_size++;

    if (m_size >= new_size)
        return true;

    if (!is_growable())
        return false;

    if (!exact)
        new_size = (new_size + 63) & ~63;

    const int32 old_size = m_size;
    m_size = new_size;
    if (m_size != new_size)
    {
        // Overflow!
        m_size = old_size;
        return false;
    }

    TYPE* new_data = (TYPE*)malloc(new_size * sizeof(TYPE));
    memcpy(new_data, c_str(), old_size * sizeof(TYPE));

    free_data();

    m_data = new_data;
    m_owns_ptr = 1;
    return true;
}

//------------------------------------------------------------------------------
template <typename TYPE>
void str_impl<TYPE>::free_data()
{
#if defined(__MINGW32__) || defined(__MINGW64__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wfree-nonheap-object" /* gcc fails to account for m_owns_ptr */
#endif

    if (m_owns_ptr)
        free(m_data);

#if defined(__MINGW32__) || defined(__MINGW64__)
#pragma GCC diagnostic pop
#endif
}

//------------------------------------------------------------------------------
template <typename TYPE>
TYPE* str_impl<TYPE>::data()
{
    m_length = 0;
    return m_data;
}

//------------------------------------------------------------------------------
template <typename TYPE>
const TYPE* str_impl<TYPE>::c_str() const
{
    return m_data;
}

//------------------------------------------------------------------------------
template <typename TYPE>
uint32 str_impl<TYPE>::size() const
{
    return m_size;
}

//------------------------------------------------------------------------------
template <typename TYPE>
bool str_impl<TYPE>::is_growable() const
{
    return m_growable;
}

//------------------------------------------------------------------------------
template <typename TYPE>
uint32 str_impl<TYPE>::length() const
{
    if (!m_length)
        m_length = str_len(c_str());

    return m_length;
}

//------------------------------------------------------------------------------
template <typename TYPE>
uint32 str_impl<TYPE>::char_count() const
{
    return ::char_count(c_str());
}

//------------------------------------------------------------------------------
template <typename TYPE>
void str_impl<TYPE>::clear()
{
    m_data[0] = '\0';
    m_length = 0;
}

//------------------------------------------------------------------------------
template <typename TYPE>
bool str_impl<TYPE>::empty() const
{
    return (c_str()[0] == '\0');
}

//------------------------------------------------------------------------------
template <typename TYPE>
void str_impl<TYPE>::truncate(uint32 pos)
{
    if (pos >= m_size)
        return;

    m_data[pos] = '\0';
    m_length = pos;
}

//------------------------------------------------------------------------------
template <typename TYPE>
void str_impl<TYPE>::trim()
{
    TYPE* pos = m_data;
    TYPE* end = m_data + length();

    while (end > pos)
    {
        if (end[-1] != ' ' && end[-1] != '\t' && end[-1] != '\r' && end[-1] != '\n')
            break;
        end--;
    }

    if (end < m_data + m_size)
    {
        *end = '\0';
        m_length = size_type(end - pos);
    }

    while (pos < end)
    {
        if (pos[0] != ' ' && pos[0] != '\t')
            break;
        pos++;
    }

    if (pos > m_data)
    {
        m_length -= size_type(pos - m_data);
        memmove(m_data, pos, (m_length + 1) * sizeof(m_data[0]));
    }
}

//------------------------------------------------------------------------------
template <typename TYPE>
int32 str_impl<TYPE>::first_of(int32 c) const
{
    const TYPE* r = str_chr(c_str(), c);
    return r ? int32(r - c_str()) : -1;
}

//------------------------------------------------------------------------------
template <typename TYPE>
int32 str_impl<TYPE>::last_of(int32 c) const
{
    const TYPE* r = str_rchr(c_str(), c);
    return r ? int32(r - c_str()) : -1;
}

//------------------------------------------------------------------------------
template <typename TYPE>
bool str_impl<TYPE>::equals(const TYPE* rhs) const
{
    return (str_cmp(c_str(), rhs) == 0);
}

//------------------------------------------------------------------------------
template <typename TYPE>
bool str_impl<TYPE>::iequals(const TYPE* rhs) const
{
    return (str_icmp(c_str(), rhs) == 0);
}

//------------------------------------------------------------------------------
template <typename TYPE>
bool str_impl<TYPE>::copy(const TYPE* src)
{
    clear();
    return concat(src);
}

//------------------------------------------------------------------------------
template <typename TYPE>
bool str_impl<TYPE>::concat(const TYPE* src, int32 n)
{
    if (src == nullptr)
        return false;

    if (n < 0)
        n = str_len(src);

    int32 len = length();
    reserve(len + n);

    int32 remaining = m_size - len - 1;

    bool truncated = (remaining < n);
    if (!truncated)
        remaining = n;

    if (remaining > 0)
    {
        // Egad.  Mingw chooses the (&rhs)[I] variant of operator<< for:
        //      char buf[10] = {'x'};
        //      code << buf;
        // So always be safe and stop copying at a NUL character.
        //
        // Callers who need NUL characters included (like translated key
        // sequence chords, e.g. ^@) must use concat_no_truncate() instead.
        TYPE* dst = m_data + len;
        while (remaining-- && *src)
            *(dst++) = *(src++);
        m_length = uint32(dst - m_data);
        m_data[m_length] = '\0';
    }

    return !truncated;
}

//------------------------------------------------------------------------------
template <typename TYPE>
bool str_impl<TYPE>::concat_no_truncate(const TYPE* src, int32 n)
{
    if (src == nullptr)
        return false;
    if (n < 0)
        return false;
    if (n == 0)
        return true;

    int32 len = length();
    reserve(len + n);

    int32 remaining = m_size - len - 1;
    if (remaining < n)
        return false;

    memcpy(m_data + len, src, n * sizeof(TYPE));
    m_length += n;
    m_data[m_length] = '\0';
    return true;
}

//------------------------------------------------------------------------------
template <typename TYPE>
inline bool str_impl<TYPE>::format(const TYPE* format, ...)
{
    va_list args;
    va_start(args, format);

    clear();
    const bool ret = vformat_append(format, args);

    va_end(args);
    return ret;
}

//------------------------------------------------------------------------------
template <typename TYPE>
inline bool str_impl<TYPE>::vformat(const TYPE* format, va_list args)
{
    clear();
    return vformat_append(format, args);
}

//------------------------------------------------------------------------------
template <typename TYPE>
inline bool str_impl<TYPE>::format_append(const TYPE* format, ...)
{
    va_list args;
    va_start(args, format);

    const bool ret = vformat_append(format, args);

    va_end(args);
    return ret;
}

//------------------------------------------------------------------------------
template <>
inline bool str_impl<char>::vformat_append(const char* format, va_list args)
{
    const int32 orig_len = length();
    assert(orig_len < m_size);
    int32 len = vsnprint(m_data + orig_len, m_size - orig_len, format, args);
    assert(len >= 0); // Compiler should comply with spec.
    if (orig_len + len >= int32(m_size) && reserve(orig_len + len))
    {
        len = vsnprint(m_data + orig_len, m_size - orig_len, format, args);
        assert(orig_len + len < m_size);
        assert(!m_data[orig_len + len]);
    }
    len += orig_len;

    m_data[m_size - 1] = '\0';
    m_length = 0;
    assert(str_len(m_data) < m_size);

    return (!len || (uint32)len < m_size);
}

//------------------------------------------------------------------------------
template <>
inline bool str_impl<wchar_t>::vformat_append(const wchar_t* format, va_list args)
{
    const uint32 orig_len = length();
    assert(orig_len < m_size);
    int32 len = vsnprint(m_data + orig_len, m_size - 1 - orig_len, format, args);
    if (len < 0 && is_growable())
    {
        // _vsnwprintf works differently and only indicates how much space is
        // needed if explicitly asked.
        len = vsnprint(nullptr, 0, format, args);
        if (len >= 0 && reserve(orig_len + len))
        {
            len = vsnprint(m_data + orig_len, m_size - 1 - orig_len, format, args);
            assert(orig_len + len < m_size);
            assert(!m_data[orig_len + len]);
        }
    }
    len += orig_len;

    m_data[m_size - 1] = '\0';
    m_length = 0;
    assert(str_len(m_data) < m_size);

    return (!len || (uint32)len < m_size);
}

//------------------------------------------------------------------------------
template <typename TYPE>
TYPE str_impl<TYPE>::operator [] (uint32 i) const
{
    return (i < length()) ? c_str()[i] : 0;
}

//------------------------------------------------------------------------------
template <typename TYPE>
str_impl<TYPE>& str_impl<TYPE>::operator << (const TYPE* rhs)
{
    concat(rhs);
    return *this;
}

//------------------------------------------------------------------------------
template <typename TYPE> template <int32 I>
str_impl<TYPE>& str_impl<TYPE>::operator << (const TYPE (&rhs)[I])
{
    concat(rhs, I - 1);
    return *this;
}

//------------------------------------------------------------------------------
template <typename TYPE>
str_impl<TYPE>& str_impl<TYPE>::operator << (const str_impl& rhs)
{
    concat_no_truncate(rhs.c_str(), rhs.length());
    return *this;
}

//------------------------------------------------------------------------------
template <typename TYPE>
str_impl<TYPE>& str_impl<TYPE>::operator = (str_impl&& s) noexcept
{
    assert(s.m_owns_ptr); // Otherwise our m_data will point into s.

    free_data();

    memcpy(this, &s, sizeof(*this));

    // This leaves s in a non-reusable state!  But s can be repaired by using
    // reset_not_owned().
    s.m_data = nullptr;
    s.m_size = 0;
    s.m_length = 0;
    s.m_owns_ptr = false;

    return *this;
}

//------------------------------------------------------------------------------
template <typename TYPE>
bool str_impl<TYPE>::owns_ptr() const
{
    return m_owns_ptr;
}

//------------------------------------------------------------------------------
template <typename TYPE>
void str_impl<TYPE>::reset_not_owned(TYPE* data, uint32 size)
{
    // reset_not_owned() can be used to repair this back into a reusable state
    // after invoking operator=(str_impl&&).
    m_data = data;
    m_size = size;
    m_owns_ptr = false;
    m_length = 0;
}



//------------------------------------------------------------------------------
template <typename T> class str_iter_impl;

int32 to_utf8(class str_base& out, const wchar_t* utf16);
int32 to_utf8(class str_base& out, const wchar_t* utf16, int32 len);
int32 to_utf8(class str_base& out, str_iter_impl<wchar_t>& iter);
int32 to_utf8(char* out, int32 max_count, const wchar_t* utf16);
int32 to_utf8(char* out, int32 max_count, str_iter_impl<wchar_t>& iter);

int32 to_utf16(class wstr_base& out, const char* utf8);
int32 to_utf16(class wstr_base& out, const char* utf8, int32 len);
int32 to_utf16(class wstr_base& out, str_iter_impl<char>& iter);
int32 to_utf16(wchar_t* out, int32 max_count, const char* utf8);
int32 to_utf16(wchar_t* out, int32 max_count, str_iter_impl<char>& iter);



//------------------------------------------------------------------------------
class str_base : public str_impl<char>
{
public:
    template <int32 I>  str_base(char (&data)[I]) : str_impl<char>(data, I - 1) {}
                        str_base(char* data, int32 size) : str_impl<char>(data, size) {}
                        str_base(const str_base&)         = delete;
    int32               from_utf16(const wchar_t* utf16)  { clear(); return to_utf8(*this, utf16); }
    void                operator = (const char* value)    { copy(value); }
    void                operator = (const wchar_t* value) { from_utf16(value); }
    void                operator = (const str_base& rhs)  = delete;
    str_base&           operator = (str_base&& rhs)       = delete;

protected:
                        str_base(str_base&&) noexcept     = default;
};

class wstr_base : public str_impl<wchar_t>
{
public:
    template <int32 I>  wstr_base(wchar_t (&data)[I]) : str_impl<wchar_t>(data, I - 1) {}
                        wstr_base(wchar_t* data, int32 size) : str_impl<wchar_t>(data, size) {}
                        wstr_base(const wstr_base&)       = delete;
    int32               from_utf8(const char* utf8)       { clear(); return to_utf16(*this, utf8); }
    using               str_impl<wchar_t>::operator =;
    void                operator = (const wchar_t* value) { copy(value); }
    void                operator = (const char* value)    { from_utf8(value); }
    void                operator = (const wstr_base&)     = delete;
    wstr_base&          operator = (wstr_base&& rhs)      = delete;

protected:
                        wstr_base(wstr_base&&) noexcept   = default;
};



//------------------------------------------------------------------------------
template <int32 COUNT=128, bool GROWABLE=true>
class str : public str_base
{
public:
                str() : str_base(m_data, COUNT)     { clear(); set_growable(GROWABLE); }
    explicit    str(const char* value) : str()      { copy(value); }
    explicit    str(const wchar_t* value) : str()   { from_utf16(value); }
                str(str<COUNT, GROWABLE>&& rhs) noexcept : str() { *this = std::move(rhs); };
                str(const str&) = delete;
    using       str_base::operator =;
    str<COUNT, GROWABLE>& operator = (str<COUNT, GROWABLE>&&) noexcept;

private:
    char        m_data[COUNT];
};

template <int32 COUNT=128, bool GROWABLE=true>
class wstr : public wstr_base
{
public:
                wstr() : wstr_base(m_data, COUNT)   { clear(); set_growable(GROWABLE); }
    explicit    wstr(const wchar_t* value) : wstr() { copy(value); }
    explicit    wstr(const char* value) : wstr()    { from_utf8(value); }
                wstr(wstr<COUNT, GROWABLE>&& rhs) noexcept : wstr() { *this = std::move(rhs); };
                wstr(const wstr&) = delete;
    using       wstr_base::operator =;
    wstr<COUNT, GROWABLE>& operator = (wstr<COUNT, GROWABLE>&&) noexcept;

private:
    wchar_t     m_data[COUNT];
};

template <int32 COUNT, bool GROWABLE>
str<COUNT, GROWABLE>& str<COUNT, GROWABLE>::operator = (str<COUNT, GROWABLE>&& rhs) noexcept
{
    assert(&rhs != this);
    assert(GROWABLE == is_growable());
    assert(GROWABLE == rhs.is_growable());
    if (rhs.owns_ptr())
    {
        const int32 len = rhs.length();
        attach(rhs.data(), rhs.size());
        rhs.reset_not_owned(rhs.m_data, COUNT);
        rhs.truncate(0);
        truncate(len); // Sneaky way to set m_length.
    }
    else
    {
        free_data();
        reset_not_owned(m_data, COUNT);
        copy(rhs.c_str());
    }
    return *this;
}

template <int32 COUNT, bool GROWABLE>
wstr<COUNT, GROWABLE>& wstr<COUNT, GROWABLE>::operator = (wstr<COUNT, GROWABLE>&& rhs) noexcept
{
    assert(&rhs != this);
    assert(GROWABLE == is_growable());
    assert(GROWABLE == rhs.is_growable());
    if (rhs.owns_ptr())
    {
        const int32 len = rhs.length();
        attach(rhs.data(), rhs.size());
        rhs.reset_not_owned(rhs.m_data, COUNT);
        rhs.truncate(0);
        truncate(len); // Sneaky way to set m_length.
    }
    else
    {
        free_data();
        reset_not_owned(m_data, COUNT);
        copy(rhs.c_str());
    }
    return *this;
}



//------------------------------------------------------------------------------
class str_moveable : public str_base
{
public:
                str_moveable();
    explicit    str_moveable(const char* value) : str_moveable()    { copy(value); }
    explicit    str_moveable(const wchar_t* value) : str_moveable() { from_utf16(value); }
                str_moveable(const str_moveable&) = delete; // (Did you forget const& in a for range loop?)
                str_moveable(str_moveable&& s) noexcept : str_moveable() { *this = std::move(s); }
#ifdef DEBUG
                ~str_moveable();
#endif
    using       str_base::operator =;
    str_moveable& operator = (str_moveable&&) noexcept;

    char*       detach();
    void        free();

private:
    void        reset_empty();
};

class wstr_moveable : public wstr_base
{
public:
                wstr_moveable();
    explicit    wstr_moveable(const wchar_t* value) : wstr_moveable() { copy(value); }
    explicit    wstr_moveable(const char* value) : wstr_moveable()  { from_utf8(value); }
                wstr_moveable(const wstr_moveable&) = delete; // (Did you forget const& in a for range loop?)
                wstr_moveable(wstr_moveable&& s) noexcept : wstr_moveable() { *this = std::move(s); }
#ifdef DEBUG
                ~wstr_moveable();
#endif
    using       wstr_base::operator =;
    wstr_moveable& operator = (wstr_moveable&&) noexcept;

    wchar_t*    detach();
    void        free();

private:
    void        reset_empty();
};



//------------------------------------------------------------------------------
template <typename T> void concat_strip_quotes(str_impl<T>& out, const T* in, uint32 len=-1)
{
    if (len == uint32(-1))
        len = uint32(strlen(in));

    // Strip quotes while concatenating.  This may seem surprising, but it's a
    // technique lifted from CMD, and it works well.
    out.reserve(out.length() + len);
    while (len)
    {
        const T* append = in;
        while (len)
        {
            if (*in == '"')
                break;
            in++;
            len--;
        }

        out.concat(append, uint32(in - append));

        while (len && *in == '"')
        {
            in++;
            len--;
        }
    }
}
